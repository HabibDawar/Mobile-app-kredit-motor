package com.example.pr_kreditmotor;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class DataMotorActivity extends AppCompatActivity implements View.OnClickListener {

    Motor motor = new Motor();
    TableLayout tbMotor;
    HorizontalScrollView horizontalScrollView;
    TextView tvTitle;
    Button btTambahMotor, btRefreshDataMotor, btSortHarga, btSortNama, btSearch;
    EditText etSearch;
    ArrayList<Button> buttonEdit = new ArrayList<Button>();
    ArrayList<Button> buttonDelete = new ArrayList<Button>();
    JSONArray arrayMotor;
    JSONArray originalArrayMotor;
    SessionManager session;

    // Sorting state
    private boolean sortHargaAscending = true;
    private boolean sortNamaAscending = true;

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_motor);

        session = new SessionManager(this);

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        // Initialize views
        tbMotor = (TableLayout) findViewById(R.id.tbMotor);
        horizontalScrollView = (HorizontalScrollView) findViewById(R.id.horizontalScrollView);
        tvTitle = (TextView) findViewById(R.id.tvTitle);
        btTambahMotor = (Button) findViewById(R.id.btTambahMotor);
        btRefreshDataMotor = (Button) findViewById(R.id.btRefreshDataMotor);
        btSortHarga = (Button) findViewById(R.id.btSortHarga);
        btSortNama = (Button) findViewById(R.id.btSortNama);
        btSearch = (Button) findViewById(R.id.btSearch);
        etSearch = (EditText) findViewById(R.id.etSearch);

        // Setup button listeners untuk sorting dan searching
        btSortHarga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sortByHarga();
            }
        });

        btSortNama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sortByNama();
            }
        });

        btSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchMotor();
            }
        });

        btRefreshDataMotor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etSearch.setText("");
                tampildataMotor();
            }
        });

        // Sembunyikan tombol tambah untuk pelanggan
        if (session.getUserLevel().equals("pelanggan")) {
            btTambahMotor.setVisibility(View.GONE);
            btSortNama.setVisibility(View.GONE);
            btSortHarga.setVisibility(View.GONE);
        }

        tampildataMotor();
    }

    public void KlikbtTambahMotor(View v) {
        tambahMotor();
    }

    public void KlikbtRefreshDataMotor(View v) {
        etSearch.setText("");
        tampildataMotor();
    }

    public void tampildataMotor() {
        try {
            arrayMotor = new JSONArray(motor.tampilMotor());
            originalArrayMotor = new JSONArray(arrayMotor.toString());
            displayMotorData(arrayMotor);
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading data", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayMotorData(JSONArray dataArray) {
        // Clear existing table
        tbMotor.removeAllViews();

        // Create header row dengan style biru
        TableRow headerRow = new TableRow(this);
        headerRow.setBackgroundColor(Color.parseColor("#1976D2"));

        // Column configuration
        String[] headers;
        int[] minWidths;

        if (session.getUserLevel().equals("admin")) {
            headers = new String[]{"No", "Kode Motor", "Nama Motor", "Harga", "Aksi"};
            minWidths = new int[]{
                    dpToPx(30),   // No
                    dpToPx(100),  // Kode Motor
                    dpToPx(120),  // Nama Motor
                    dpToPx(150),  // Harga
                    dpToPx(120)   // Aksi
            };
        } else {
            headers = new String[]{"No", "Kode Motor", "Nama Motor", "Harga"};
            minWidths = new int[]{
                    dpToPx(30),   // No
                    dpToPx(100),  // Kode Motor
                    dpToPx(120),  // Nama Motor
                    dpToPx(150)   // Harga
            };
        }

        for (int i = 0; i < headers.length; i++) {
            TextView headerView = createHeaderTextView(headers[i]);
            TableRow.LayoutParams params = new TableRow.LayoutParams(
                    minWidths[i],
                    TableRow.LayoutParams.WRAP_CONTENT
            );
            headerView.setLayoutParams(params);
            headerRow.addView(headerView);
        }

        tbMotor.addView(headerRow);

        try {
            buttonEdit.clear();
            buttonDelete.clear();

            for (int i = 0; i < dataArray.length(); i++) {
                JSONObject jsonChildNode = dataArray.getJSONObject(i);
                String idmotor = jsonChildNode.optString("idmotor");
                String kdmotor = jsonChildNode.optString("kdmotor");
                String nama = jsonChildNode.optString("nama");
                String harga = jsonChildNode.optString("harga");

                TableRow dataRow = new TableRow(this);
                dataRow.setBackgroundColor(i % 2 == 0 ? Color.parseColor("#FFFFFF") : Color.parseColor("#F5F5F5"));
                dataRow.setMinimumHeight(dpToPx(45));

                // No
                addDataCell(dataRow, String.valueOf(i + 1), minWidths[0], Gravity.CENTER);

                // Kode Motor
                addDataCell(dataRow, kdmotor, minWidths[1], Gravity.CENTER);

                // Nama Motor
                addDataCell(dataRow, nama, minWidths[2], Gravity.START);

                // Harga
                String hargaFormatted = "Rp " + formatNumber(harga);
                addDataCell(dataRow, hargaFormatted, minWidths[3], Gravity.END);

                // Action buttons (admin only)
                if (session.getUserLevel().equals("admin")) {
                    LinearLayout actionLayout = new LinearLayout(this);
                    actionLayout.setOrientation(LinearLayout.HORIZONTAL);
                    actionLayout.setGravity(Gravity.CENTER);

                    TableRow.LayoutParams actionParams = new TableRow.LayoutParams(
                            minWidths[4],
                            TableRow.LayoutParams.WRAP_CONTENT
                    );
                    actionLayout.setLayoutParams(actionParams);

                    Button btnEdit = createActionButton("EDIT", Color.parseColor("#2196F3"));
                    btnEdit.setId(Integer.parseInt(idmotor));
                    btnEdit.setTag("Edit");
                    btnEdit.setOnClickListener(this);

                    Button btnDelete = createActionButton("HAPUS", Color.parseColor("#F44336"));
                    btnDelete.setId(Integer.parseInt(idmotor));
                    btnDelete.setTag("Delete");
                    btnDelete.setOnClickListener(this);

                    actionLayout.addView(btnEdit);
                    actionLayout.addView(btnDelete);
                    dataRow.addView(actionLayout);

                    buttonEdit.add(btnEdit);
                    buttonDelete.add(btnDelete);
                }

                tbMotor.addView(dataRow);
            }

            // Empty state
            if (dataArray.length() == 0) {
                TableRow emptyRow = new TableRow(this);
                int spanCount = session.getUserLevel().equals("admin") ? 5 : 4;

                TextView emptyText = new TextView(this);
                emptyText.setText("Tidak ada data motor");
                emptyText.setTextColor(Color.GRAY);
                emptyText.setTypeface(Typeface.DEFAULT_BOLD);
                emptyText.setGravity(Gravity.CENTER);
                emptyText.setPadding(dpToPx(16), dpToPx(40), dpToPx(16), dpToPx(40));

                TableRow.LayoutParams params = new TableRow.LayoutParams(
                        TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.WRAP_CONTENT
                );
                params.span = spanCount;
                emptyText.setLayoutParams(params);
                emptyRow.addView(emptyText);
                tbMotor.addView(emptyRow);
            }

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error menampilkan data", Toast.LENGTH_SHORT).show();
        }
    }

    // Helper methods untuk tampilan tabel
    private void addDataCell(TableRow row, String text, int minWidth, int gravity) {
        TextView textView = createDataCell(text, minWidth, gravity);
        row.addView(textView);
    }

    private TextView createDataCell(String text, int minWidth, int gravity) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(dpToPx(8), dpToPx(12), dpToPx(8), dpToPx(12));
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        textView.setGravity(gravity);
        textView.setSingleLine(true);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setTextColor(Color.parseColor("#333333"));
        textView.setTypeface(Typeface.DEFAULT);

        TableRow.LayoutParams params = new TableRow.LayoutParams(
                minWidth,
                TableRow.LayoutParams.WRAP_CONTENT
        );
        textView.setLayoutParams(params);

        return textView;
    }

    private TextView createHeaderTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextColor(Color.WHITE);
        textView.setPadding(dpToPx(8), dpToPx(12), dpToPx(8), dpToPx(12));
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setGravity(Gravity.CENTER);
        textView.setSingleLine(true);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setBackgroundColor(Color.parseColor("#1976D2"));
        return textView;
    }

    private Button createActionButton(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        button.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setAllCaps(false);

        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadius(dpToPx(4));
        shape.setColor(color);
        button.setBackground(shape);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                dpToPx(60),
                dpToPx(36)
        );
        params.setMargins(dpToPx(2), 0, dpToPx(2), 0);
        button.setLayoutParams(params);

        return button;
    }

    private int dpToPx(int dp) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp,
                getResources().getDisplayMetrics()
        );
    }

    // Format number tanpa pemendekan
    private String formatNumber(String number) {
        try {
            long value = Long.parseLong(number);
            return String.format("%,d", value).replace(',', '.');
        } catch (NumberFormatException e) {
            return number;
        }
    }

    // ALGORITMA SORTING BY HARGA
    private void sortByHarga() {
        try {
            List<JSONObject> motorList = new ArrayList<>();
            for (int i = 0; i < arrayMotor.length(); i++) {
                motorList.add(arrayMotor.getJSONObject(i));
            }

            Collections.sort(motorList, new Comparator<JSONObject>() {
                @Override
                public int compare(JSONObject o1, JSONObject o2) {
                    try {
                        int harga1 = Integer.parseInt(o1.getString("harga"));
                        int harga2 = Integer.parseInt(o2.getString("harga"));
                        return sortHargaAscending ? Integer.compare(harga1, harga2) : Integer.compare(harga2, harga1);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        return 0;
                    }
                }
            });

            sortHargaAscending = !sortHargaAscending;
            btSortHarga.setText(sortHargaAscending ? "SORT HARGA ↑" : "SORT HARGA ↓");

            JSONArray sortedArray = new JSONArray();
            for (JSONObject obj : motorList) {
                sortedArray.put(obj);
            }

            displayMotorData(sortedArray);
            Toast.makeText(this, "Data diurutkan berdasarkan harga", Toast.LENGTH_SHORT).show();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    // ALGORITMA SORTING BY NAMA
    private void sortByNama() {
        try {
            List<JSONObject> motorList = new ArrayList<>();
            for (int i = 0; i < arrayMotor.length(); i++) {
                motorList.add(arrayMotor.getJSONObject(i));
            }

            Collections.sort(motorList, new Comparator<JSONObject>() {
                @Override
                public int compare(JSONObject o1, JSONObject o2) {
                    try {
                        String nama1 = o1.getString("nama").toLowerCase();
                        String nama2 = o2.getString("nama").toLowerCase();
                        return sortNamaAscending ? nama1.compareTo(nama2) : nama2.compareTo(nama1);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        return 0;
                    }
                }
            });

            sortNamaAscending = !sortNamaAscending;
            btSortNama.setText(sortNamaAscending ? "SORT NAMA ↑" : "SORT NAMA ↓");

            JSONArray sortedArray = new JSONArray();
            for (JSONObject obj : motorList) {
                sortedArray.put(obj);
            }

            displayMotorData(sortedArray);
            Toast.makeText(this, "Data diurutkan berdasarkan nama", Toast.LENGTH_SHORT).show();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    // ALGORITMA SEARCHING
    private void searchMotor() {
        String searchText = etSearch.getText().toString().trim().toLowerCase();

        if (TextUtils.isEmpty(searchText)) {
            displayMotorData(originalArrayMotor);
            return;
        }

        try {
            JSONArray filteredArray = new JSONArray();

            for (int i = 0; i < originalArrayMotor.length(); i++) {
                JSONObject motor = originalArrayMotor.getJSONObject(i);
                String kdmotor = motor.getString("kdmotor").toLowerCase();
                String nama = motor.getString("nama").toLowerCase();
                String harga = motor.getString("harga");

                if (kdmotor.contains(searchText) ||
                        nama.contains(searchText) ||
                        harga.contains(searchText)) {
                    filteredArray.put(motor);
                }
            }

            if (filteredArray.length() > 0) {
                arrayMotor = filteredArray;
                displayMotorData(filteredArray);
                Toast.makeText(this, "Ditemukan " + filteredArray.length() + " data", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Data tidak ditemukan", Toast.LENGTH_SHORT).show();
                displayMotorData(originalArrayMotor);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void deleteMotor(int idmotor) {
        // Hanya admin yang bisa delete
        if (!session.getUserLevel().equals("admin")) {
            Toast.makeText(this, "Akses ditolak - Hanya admin yang bisa menghapus", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Konfirmasi Hapus")
                .setMessage("Apakah Anda yakin ingin menghapus motor ini?")
                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String result = motor.deleteMotor(idmotor);
                        Toast.makeText(DataMotorActivity.this, result, Toast.LENGTH_SHORT).show();
                        finish();
                        startActivity(getIntent());
                    }
                })
                .setNegativeButton("Tidak", null)
                .show();
    }

    public void getMotorByKdmotor(int idmotor) {
        // Hanya admin yang bisa edit
        if (!session.getUserLevel().equals("admin")) {
            Toast.makeText(this, "Akses ditolak - Hanya admin yang bisa mengedit", Toast.LENGTH_SHORT).show();
            return;
        }

        String idmotorEdit = null;
        String kdmotorEdit = null;
        String namaEdit = null;
        String hargaEdit = null;

        JSONArray arrayPersonal;

        try {
            arrayPersonal = new JSONArray(motor.getMotorByKdmotor(idmotor));
            for (int i = 0; i < arrayPersonal.length(); i++) {
                JSONObject jsonChildNode = arrayPersonal.getJSONObject(i);
                idmotorEdit = jsonChildNode.optString("idmotor");
                kdmotorEdit = jsonChildNode.optString("kdmotor");
                namaEdit = jsonChildNode.optString("nama");
                hargaEdit = jsonChildNode.optString("harga");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        LinearLayout layoutInput = new LinearLayout(this);
        layoutInput.setOrientation(LinearLayout.VERTICAL);

        final TextView viewKdmotor = new TextView(this);
        viewKdmotor.setText("Kode Motor = " + String.valueOf(kdmotorEdit));
        viewKdmotor.setTextColor(Color.BLACK);
        viewKdmotor.setTextSize(16);
        layoutInput.addView(viewKdmotor);

        final EditText editIdMotor = new EditText(this);
        editIdMotor.setText(idmotorEdit);
        editIdMotor.setVisibility(View.GONE);
        layoutInput.addView(editIdMotor);

        final EditText editNama = new EditText(this);
        editNama.setText(namaEdit);
        editNama.setHint("Nama Motor");
        layoutInput.addView(editNama);

        final EditText editHarga = new EditText(this);
        editHarga.setText(hargaEdit);
        editHarga.setHint("Harga");
        editHarga.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        layoutInput.addView(editHarga);

        AlertDialog.Builder builderEditMotor = new AlertDialog.Builder(this);
        builderEditMotor.setTitle("Update Motor");
        builderEditMotor.setView(layoutInput);
        builderEditMotor.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String idmotor = editIdMotor.getText().toString();
                String kdmotor = viewKdmotor.getText().toString();
                String nama = editNama.getText().toString();
                String harga = editHarga.getText().toString();

                System.out.println("IdMotor : " + idmotor + " KdMotor : " + kdmotor + " Nama : " + nama + " Harga : " + harga);

                String laporan = motor.updateMotor(idmotor, kdmotor, nama, harga);
                Toast.makeText(DataMotorActivity.this, laporan, Toast.LENGTH_SHORT).show();
                finish();
                startActivity(getIntent());
            }
        });

        builderEditMotor.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builderEditMotor.show();
    }

    public void tambahMotor() {
        // Hanya admin yang bisa tambah
        if (!session.getUserLevel().equals("admin")) {
            Toast.makeText(this, "Akses ditolak - Hanya admin yang bisa menambah", Toast.LENGTH_SHORT).show();
            return;
        }

        LinearLayout layoutInput = new LinearLayout(this);
        layoutInput.setOrientation(LinearLayout.VERTICAL);

        final EditText editKdMotor = new EditText(this);
        editKdMotor.setHint("KdMotor");
        layoutInput.addView(editKdMotor);

        final EditText editNama = new EditText(this);
        editNama.setHint("Nama");
        layoutInput.addView(editNama);

        final EditText editHarga = new EditText(this);
        editHarga.setHint("Harga");
        editHarga.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        layoutInput.addView(editHarga);

        AlertDialog.Builder builderInsertMotor = new AlertDialog.Builder(this);
        builderInsertMotor.setTitle("Insert Motor");
        builderInsertMotor.setView(layoutInput);
        builderInsertMotor.setPositiveButton("Insert", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String kdmotor = editKdMotor.getText().toString();
                String nama = editNama.getText().toString();
                String harga = editHarga.getText().toString();

                System.out.println("KdMotor : " + kdmotor + " Nama : " + nama + " Harga : " + harga);

                String laporan = motor.insertMotor(kdmotor, nama, harga);
                Toast.makeText(DataMotorActivity.this, laporan, Toast.LENGTH_SHORT).show();
                finish();
                startActivity(getIntent());
            }
        });

        builderInsertMotor.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builderInsertMotor.show();
    }

    @Override
    public void onClick(View view) {
        // Hanya admin yang bisa klik tombol edit/delete
        if (!session.getUserLevel().equals("admin")) {
            return;
        }

        for (int i = 0; i < buttonEdit.size(); i++) {
            if (view.getId() == buttonEdit.get(i).getId() &&
                    view.getTag().toString().trim().equals("Edit")) {
                int idmotor = buttonEdit.get(i).getId();
                getMotorByKdmotor(idmotor);
            } else if (view.getId() == buttonDelete.get(i).getId() &&
                    view.getTag().toString().trim().equals("Delete")) {
                int idmotor = buttonDelete.get(i).getId();
                deleteMotor(idmotor);
            }
        }
    }
}