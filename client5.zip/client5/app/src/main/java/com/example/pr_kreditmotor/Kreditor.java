package com.example.pr_kreditmotor;

public class Kreditor extends Koneksi {
    Server server = new Server();
    String SERVER = server.urlDatabase1();
    String URL = "http://" + SERVER + "/jskreditmotor/tbkreditor.php";
    String url = "";
    String response = "";

    // Method dasar
    public String tampilKreditor() {
        try {
            url = URL + "?operasi=view";
            response = call(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    public String insertKreditor(String nama, String pekerjaan, String telp, String alamat) {
        try {
            nama = nama.replace(" ", "%20");
            pekerjaan = pekerjaan.replace(" ", "%20");
            alamat = alamat.replace(" ", "%20");
            url = URL + "?operasi=insert&nama=" + nama + "&pekerjaan=" + pekerjaan + "&telp=" + telp + "&alamat=" + alamat;
            response = call(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    public String updateKreditor(String idkreditor, String nama, String pekerjaan, String telp, String alamat) {
        try {
            nama = nama.replace(" ", "%20");
            pekerjaan = pekerjaan.replace(" ", "%20");
            alamat = alamat.replace(" ", "%20");
            url = URL + "?operasi=update&idkreditor=" + idkreditor + "&nama=" + nama + "&pekerjaan=" + pekerjaan + "&telp=" + telp + "&alamat=" + alamat;
            response = call(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    public String deleteKreditor(String idkreditor) {
        try {
            url = URL + "?operasi=delete&idkreditor=" + idkreditor;
            response = call(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    // Method untuk select data
    public String select_by_Idkreditor(String idkreditor) {
        try {
            url = URL + "?operasi=get_kreditor_by_id&idkreditor=" + idkreditor;
            System.out.println("URL Get Kreditor by ID: " + url);
            response = call(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    // Method untuk kompatibilitas - jika masih dipanggil di activity lain
    public String tampilKreditorbyIdNama() {
        try {
            // Gunakan operasi yang sesuai, default ke 'view'
            url = URL + "?operasi=view";
            System.out.println("URL Tampil Kreditor by Id Nama: " + url);
            response = call(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    public String select_by_idnama() {
        return tampilKreditor(); // alias untuk tampilKreditor
    }

    // Method untuk profil
    public String update_kreditor(String idkreditor, String nama, String alamat, String telepon, String email) {
        try {
            nama = nama.replace(" ", "%20");
            alamat = alamat.replace(" ", "%20");
            telepon = telepon.replace(" ", "%20");
            email = email != null ? email.replace(" ", "%20") : "";
            url = URL + "?operasi=update_profil&idkreditor=" + idkreditor + "&nama=" + nama + "&alamat=" + alamat + "&telepon=" + telepon + "&email=" + email;
            System.out.println("URL Update Kreditor Profil: " + url);
            response = call(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    public String update_password(String idkreditor, String password) {
        try {
            password = password.replace(" ", "%20");
            url = URL + "?operasi=update_password&idkreditor=" + idkreditor + "&password=" + password;
            System.out.println("URL Update Password Kreditor: " + url);
            response = call(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }
}