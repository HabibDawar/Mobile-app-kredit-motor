package com.example.pr_kreditmotor;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class DataPetugasActivity extends AppCompatActivity implements View.OnClickListener {

    Petugas petugas = new Petugas();
    TableLayout tbPetugas;
    HorizontalScrollView horizontalScrollView;
    TextView tvTitle;
    Button btTambahPetugas, btRefreshDataPetugas, btSortNama, btSortJabatan, btSearch;
    EditText etSearch;
    ArrayList<Button> buttonEdit = new ArrayList<Button>();
    ArrayList<Button> buttonDelete = new ArrayList<Button>();
    JSONArray arrayPetugas;
    JSONArray originalArrayPetugas;
    SessionManager session;

    // Sorting state
    private boolean sortNamaAscending = true;
    private boolean sortJabatanAscending = true;

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_petugas);

        session = new SessionManager(this);

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        // Initialize views
        tbPetugas = (TableLayout) findViewById(R.id.tbPetugas);
        horizontalScrollView = (HorizontalScrollView) findViewById(R.id.horizontalScrollView);
        tvTitle = (TextView) findViewById(R.id.tvTitle);
        btTambahPetugas = (Button) findViewById(R.id.btTambahPetugas);
        btRefreshDataPetugas = (Button) findViewById(R.id.btRefreshDataPetugas);
        btSortNama = (Button) findViewById(R.id.btSortNama);
        btSortJabatan = (Button) findViewById(R.id.btSortJabatan);
        btSearch = (Button) findViewById(R.id.btSearch);
        etSearch = (EditText) findViewById(R.id.etSearch);

        // Setup button listeners untuk sorting dan searching
        btSortNama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sortByNama();
            }
        });

        btSortJabatan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sortByJabatan();
            }
        });

        btSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchPetugas();
            }
        });

        btRefreshDataPetugas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etSearch.setText("");
                tampildataPetugas();
            }
        });

        // Sembunyikan tombol untuk pelanggan (hanya admin yang bisa akses)
        if (session.getUserLevel().equals("pelanggan")) {
            btTambahPetugas.setVisibility(View.GONE);
            btSortNama.setVisibility(View.GONE);
            btSortJabatan.setVisibility(View.GONE);
            Toast.makeText(this, "Akses ditolak - Hanya admin yang bisa melihat data petugas", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        tampildataPetugas();
    }

    public void KlikbtTambahPetugas(View v) {
        tambahPetugas();
    }

    public void klikRefreshDataMahasiswa(View v) {
        etSearch.setText("");
        tampildataPetugas();
    }

    public void tampildataPetugas() {
        try {
            arrayPetugas = new JSONArray(petugas.tampilPetugas());
            originalArrayPetugas = new JSONArray(arrayPetugas.toString());
            displayPetugasData(arrayPetugas);
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading data", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayPetugasData(JSONArray dataArray) {
        // Clear existing table
        tbPetugas.removeAllViews();

        // Create header row dengan style biru
        TableRow headerRow = new TableRow(this);
        headerRow.setBackgroundColor(Color.parseColor("#1976D2"));

        // Column configuration
        String[] headers = {"No", "Kode Petugas", "Nama", "Jabatan", "Aksi"};
        int[] minWidths = {
                dpToPx(30),   // No
                dpToPx(100),  // Kode Petugas
                dpToPx(100),  // Nama
                dpToPx(120),  // Jabatan
                dpToPx(120)   // Aksi
        };

        for (int i = 0; i < headers.length; i++) {
            TextView headerView = createHeaderTextView(headers[i]);
            TableRow.LayoutParams params = new TableRow.LayoutParams(
                    minWidths[i],
                    TableRow.LayoutParams.WRAP_CONTENT
            );
            headerView.setLayoutParams(params);
            headerRow.addView(headerView);
        }

        tbPetugas.addView(headerRow);

        try {
            buttonEdit.clear();
            buttonDelete.clear();

            for (int i = 0; i < dataArray.length(); i++) {
                JSONObject jsonChildNode = dataArray.getJSONObject(i);
                String idpetugas = jsonChildNode.optString("idpetugas");
                String kdpetugas = jsonChildNode.optString("kdpetugas");
                String nama = jsonChildNode.optString("nama");
                String jabatan = jsonChildNode.optString("jabatan");

                TableRow dataRow = new TableRow(this);
                dataRow.setBackgroundColor(i % 2 == 0 ? Color.parseColor("#FFFFFF") : Color.parseColor("#F5F5F5"));
                dataRow.setMinimumHeight(dpToPx(45));

                // No
                addDataCell(dataRow, String.valueOf(i + 1), minWidths[0], Gravity.CENTER);

                // Kode Petugas
                addDataCell(dataRow, kdpetugas, minWidths[1], Gravity.CENTER);

                // Nama
                addDataCell(dataRow, nama, minWidths[2], Gravity.START);

                // Jabatan
                addDataCell(dataRow, jabatan, minWidths[3], Gravity.START);

                // Action buttons
                LinearLayout actionLayout = new LinearLayout(this);
                actionLayout.setOrientation(LinearLayout.HORIZONTAL);
                actionLayout.setGravity(Gravity.CENTER);

                TableRow.LayoutParams actionParams = new TableRow.LayoutParams(
                        minWidths[4],
                        TableRow.LayoutParams.WRAP_CONTENT
                );
                actionLayout.setLayoutParams(actionParams);

                Button btnEdit = createActionButton("EDIT", Color.parseColor("#2196F3"));
                btnEdit.setId(Integer.parseInt(idpetugas));
                btnEdit.setTag("Edit");
                btnEdit.setOnClickListener(this);

                Button btnDelete = createActionButton("HAPUS", Color.parseColor("#F44336"));
                btnDelete.setId(Integer.parseInt(idpetugas));
                btnDelete.setTag("Delete");
                btnDelete.setOnClickListener(this);

                actionLayout.addView(btnEdit);
                actionLayout.addView(btnDelete);
                dataRow.addView(actionLayout);

                buttonEdit.add(btnEdit);
                buttonDelete.add(btnDelete);

                tbPetugas.addView(dataRow);
            }

            // Empty state
            if (dataArray.length() == 0) {
                TableRow emptyRow = new TableRow(this);
                TextView emptyText = new TextView(this);
                emptyText.setText("Tidak ada data petugas");
                emptyText.setTextColor(Color.GRAY);
                emptyText.setTypeface(Typeface.DEFAULT_BOLD);
                emptyText.setGravity(Gravity.CENTER);
                emptyText.setPadding(dpToPx(16), dpToPx(40), dpToPx(16), dpToPx(40));

                TableRow.LayoutParams params = new TableRow.LayoutParams(
                        TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.WRAP_CONTENT
                );
                params.span = headers.length;
                emptyText.setLayoutParams(params);
                emptyRow.addView(emptyText);
                tbPetugas.addView(emptyRow);
            }

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error menampilkan data", Toast.LENGTH_SHORT).show();
        }
    }

    // Helper methods untuk tampilan tabel
    private void addDataCell(TableRow row, String text, int minWidth, int gravity) {
        TextView textView = createDataCell(text, minWidth, gravity);
        row.addView(textView);
    }

    private TextView createDataCell(String text, int minWidth, int gravity) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(dpToPx(8), dpToPx(12), dpToPx(8), dpToPx(12));
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        textView.setGravity(gravity);
        textView.setSingleLine(true);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setTextColor(Color.parseColor("#333333"));
        textView.setTypeface(Typeface.DEFAULT);

        TableRow.LayoutParams params = new TableRow.LayoutParams(
                minWidth,
                TableRow.LayoutParams.WRAP_CONTENT
        );
        textView.setLayoutParams(params);

        return textView;
    }

    private TextView createHeaderTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextColor(Color.WHITE);
        textView.setPadding(dpToPx(8), dpToPx(12), dpToPx(8), dpToPx(12));
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setGravity(Gravity.CENTER);
        textView.setSingleLine(true);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setBackgroundColor(Color.parseColor("#1976D2"));
        return textView;
    }

    private Button createActionButton(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        button.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setAllCaps(false);

        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadius(dpToPx(4));
        shape.setColor(color);
        button.setBackground(shape);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                dpToPx(60),
                dpToPx(36)
        );
        params.setMargins(dpToPx(2), 0, dpToPx(2), 0);
        button.setLayoutParams(params);

        return button;
    }

    private int dpToPx(int dp) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp,
                getResources().getDisplayMetrics()
        );
    }

    // ALGORITMA SORTING BY NAMA
    private void sortByNama() {
        try {
            List<JSONObject> petugasList = new ArrayList<>();
            for (int i = 0; i < arrayPetugas.length(); i++) {
                petugasList.add(arrayPetugas.getJSONObject(i));
            }

            Collections.sort(petugasList, new Comparator<JSONObject>() {
                @Override
                public int compare(JSONObject o1, JSONObject o2) {
                    try {
                        String nama1 = o1.getString("nama").toLowerCase();
                        String nama2 = o2.getString("nama").toLowerCase();
                        return sortNamaAscending ? nama1.compareTo(nama2) : nama2.compareTo(nama1);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        return 0;
                    }
                }
            });

            sortNamaAscending = !sortNamaAscending;
            btSortNama.setText(sortNamaAscending ? "SORT NAMA ↑" : "SORT NAMA ↓");

            JSONArray sortedArray = new JSONArray();
            for (JSONObject obj : petugasList) {
                sortedArray.put(obj);
            }

            displayPetugasData(sortedArray);
            Toast.makeText(this, "Data diurutkan berdasarkan nama", Toast.LENGTH_SHORT).show();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    // ALGORITMA SORTING BY JABATAN
    private void sortByJabatan() {
        try {
            List<JSONObject> petugasList = new ArrayList<>();
            for (int i = 0; i < arrayPetugas.length(); i++) {
                petugasList.add(arrayPetugas.getJSONObject(i));
            }

            Collections.sort(petugasList, new Comparator<JSONObject>() {
                @Override
                public int compare(JSONObject o1, JSONObject o2) {
                    try {
                        String jabatan1 = o1.getString("jabatan").toLowerCase();
                        String jabatan2 = o2.getString("jabatan").toLowerCase();
                        return sortJabatanAscending ? jabatan1.compareTo(jabatan2) : jabatan2.compareTo(jabatan1);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        return 0;
                    }
                }
            });

            sortJabatanAscending = !sortJabatanAscending;
            btSortJabatan.setText(sortJabatanAscending ? "SORT JABATAN ↑" : "SORT JABATAN ↓");

            JSONArray sortedArray = new JSONArray();
            for (JSONObject obj : petugasList) {
                sortedArray.put(obj);
            }

            displayPetugasData(sortedArray);
            Toast.makeText(this, "Data diurutkan berdasarkan jabatan", Toast.LENGTH_SHORT).show();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    // ALGORITMA SEARCHING
    private void searchPetugas() {
        String searchText = etSearch.getText().toString().trim().toLowerCase();

        if (TextUtils.isEmpty(searchText)) {
            displayPetugasData(originalArrayPetugas);
            return;
        }

        try {
            JSONArray filteredArray = new JSONArray();

            for (int i = 0; i < originalArrayPetugas.length(); i++) {
                JSONObject petugas = originalArrayPetugas.getJSONObject(i);
                String kdpetugas = petugas.getString("kdpetugas").toLowerCase();
                String nama = petugas.getString("nama").toLowerCase();
                String jabatan = petugas.getString("jabatan").toLowerCase();

                if (kdpetugas.contains(searchText) ||
                        nama.contains(searchText) ||
                        jabatan.contains(searchText)) {
                    filteredArray.put(petugas);
                }
            }

            if (filteredArray.length() > 0) {
                arrayPetugas = filteredArray;
                displayPetugasData(filteredArray);
                Toast.makeText(this, "Ditemukan " + filteredArray.length() + " data", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Data tidak ditemukan", Toast.LENGTH_SHORT).show();
                displayPetugasData(originalArrayPetugas);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void deletePetugas(int idpetugas) {
        new AlertDialog.Builder(this)
                .setTitle("Konfirmasi Hapus")
                .setMessage("Apakah Anda yakin ingin menghapus petugas ini?")
                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        petugas.deletePetugas(idpetugas);
                        finish();
                        startActivity(getIntent());
                    }
                })
                .setNegativeButton("Tidak", null)
                .show();
    }

    public void getPetugasByKdpetugas(int idpetugas) {
        String idpetugasEdit = null;
        String kdpetugasEdit = null;
        String namaEdit = null;
        String jabatanEdit = null;

        JSONArray arrayPersonal;

        try {
            arrayPersonal = new JSONArray(petugas.getPetugasByKdpetugas(idpetugas));

            for (int i = 0; i < arrayPersonal.length(); i++) {
                JSONObject jsonChildNode = arrayPersonal.getJSONObject(i);
                idpetugasEdit = jsonChildNode.optString("idpetugas");
                kdpetugasEdit = jsonChildNode.optString("kdpetugas");
                namaEdit = jsonChildNode.optString("nama");
                jabatanEdit = jsonChildNode.optString("jabatan");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        LinearLayout layoutInput = new LinearLayout(this);
        layoutInput.setOrientation(LinearLayout.VERTICAL);

        final TextView viewKdpetugas = new TextView(this);
        viewKdpetugas.setText("Kode = "+String.valueOf(kdpetugasEdit));
        viewKdpetugas.setBackgroundColor(Color.TRANSPARENT);
        viewKdpetugas.setTextColor(Color.BLACK);
        viewKdpetugas.setTextSize(16);
        layoutInput.addView(viewKdpetugas);

        final EditText editIdPetugas = new EditText(this);
        editIdPetugas.setText(idpetugasEdit);
        editIdPetugas.setVisibility(View.GONE);
        layoutInput.addView(editIdPetugas);

        final EditText editNama = new EditText(this);
        editNama.setText(namaEdit);
        layoutInput.addView(editNama);

        final EditText editJabatan = new EditText(this);
        editJabatan.setText(jabatanEdit);
        layoutInput.addView(editJabatan);

        AlertDialog.Builder builderEditPetugas = new AlertDialog.Builder(this);
        builderEditPetugas.setTitle("Update Petugas");
        builderEditPetugas.setView(layoutInput);
        builderEditPetugas.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String idpetugas = editIdPetugas.getText().toString();
                String kdpetugas = viewKdpetugas.getText().toString();
                String nama = editNama.getText().toString();
                String jabatan = editJabatan.getText().toString();

                String laporan = petugas.updatePetugas(idpetugas, kdpetugas, nama, jabatan);
                Toast.makeText(DataPetugasActivity.this, laporan, Toast.LENGTH_SHORT).show();
                finish();
                startActivity(getIntent());
            }
        });

        builderEditPetugas.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builderEditPetugas.show();
    }

    public void tambahPetugas() {
        LinearLayout layoutInput = new LinearLayout(this);
        layoutInput.setOrientation(LinearLayout.VERTICAL);

        final EditText editKdPetugas = new EditText(this);
        editKdPetugas.setHint("KdPetugas");
        layoutInput.addView(editKdPetugas);

        final EditText editNama = new EditText(this);
        editNama.setHint("Nama");
        layoutInput.addView(editNama);

        final EditText editJabatan = new EditText(this);
        editJabatan.setHint("Jabatan");
        layoutInput.addView(editJabatan);

        AlertDialog.Builder builderInsertPetugas = new AlertDialog.Builder(this);
        builderInsertPetugas.setTitle("Insert Petugas");
        builderInsertPetugas.setView(layoutInput);
        builderInsertPetugas.setPositiveButton("Insert", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String kdpetugas = editKdPetugas.getText().toString();
                String nama = editNama.getText().toString();
                String jabatan = editJabatan.getText().toString();

                String laporan = petugas.insertPetugas(kdpetugas, nama, jabatan);
                Toast.makeText(DataPetugasActivity.this, laporan, Toast.LENGTH_SHORT).show();
                finish();
                startActivity(getIntent());
            }
        });

        builderInsertPetugas.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builderInsertPetugas.show();
    }

    @Override
    public void onClick(View view) {
        for (int i = 0; i < buttonEdit.size(); i++) {
            if (view.getId() == buttonEdit.get(i).getId() &&
                    view.getTag().toString().trim().equals("Edit")) {
                int idpetugas = buttonEdit.get(i).getId();
                getPetugasByKdpetugas(idpetugas);
            } else if (view.getId() == buttonDelete.get(i).getId() &&
                    view.getTag().toString().trim().equals("Delete")) {
                int idpetugas = buttonDelete.get(i).getId();
                deletePetugas(idpetugas);
            }
        }
    }
}