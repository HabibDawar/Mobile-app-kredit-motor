package com.example.pr_kreditmotor;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class TransaksiActivity extends AppCompatActivity {

    // Deklarasi tombol
    Button btPengajuanKredit, btPembayaranAngsuran, btDataPengajuanKredit, btApprovalKredit;
    TextView tvTitleTransaksi;
    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaksi);

        session = new SessionManager(this);

        // Hubungkan tombol dengan ID di layout XML
        btPengajuanKredit = findViewById(R.id.btPengajuanKredit);
        btPembayaranAngsuran = findViewById(R.id.btPembayaranAngsuran);
        btDataPengajuanKredit = findViewById(R.id.btDataPengajuanKredit);
        btApprovalKredit = findViewById(R.id.btApprovalKredit);
        tvTitleTransaksi = findViewById(R.id.tvTitleTransaksi);

        // Setup UI berdasarkan role
        setupRoleBasedUI();

        // Setup button listeners
        setupButtonListeners();
    }

    private void setupRoleBasedUI() {
        String userLevel = session.getUserLevel();
        String userName = session.getNama();

        if (userLevel.equals("admin")) {
            setupAdminUI(userName);
        } else if (userLevel.equals("pelanggan")) {
            setupPelangganUI(userName);
        }
    }

    private void setupAdminUI(String userName) {
        tvTitleTransaksi.setText("Transaksi - Admin Panel\nSelamat datang, " + userName);

        // Tampilkan tombol approval untuk admin
        btApprovalKredit.setVisibility(View.VISIBLE);
        btApprovalKredit.setText("Approval Pengajuan Kredit");

        // Ubah teks tombol untuk admin
        btDataPengajuanKredit.setText("Data Semua Pengajuan");
        btPembayaranAngsuran.setText("Monitoring Pembayaran");

        // Sembunyikan tombol pengajuan untuk admin (karena admin tidak mengajukan kredit)
        btPengajuanKredit.setVisibility(View.GONE);
    }

    private void setupPelangganUI(String userName) {
        tvTitleTransaksi.setText("Transaksi - Pelanggan\nSelamat datang, " + userName);

        // Sembunyikan tombol approval untuk pelanggan
        btApprovalKredit.setVisibility(View.GONE);

        // Tampilkan semua tombol untuk pelanggan
        btPengajuanKredit.setVisibility(View.VISIBLE);
        btPembayaranAngsuran.setVisibility(View.VISIBLE);
        btDataPengajuanKredit.setVisibility(View.VISIBLE);

        // Set teks default untuk pelanggan
        btPengajuanKredit.setText("Ajukan Kredit");
        btPembayaranAngsuran.setText("Bayar Angsuran");
        btDataPengajuanKredit.setText("Status Pengajuan Saya");
    }

    private void setupButtonListeners() {
        // Tombol Pengajuan Kredit
        btPengajuanKredit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                KlikbtPengajuanKredit();
            }
        });

        // Tombol Pembayaran Angsuran
        btPembayaranAngsuran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                KlikbtPembayaranAngsuran();
            }
        });

        // Tombol Data Pengajuan Kredit
        btDataPengajuanKredit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                KlikbtDataPengajuanKredit();
            }
        });

        // Tombol Approval Kredit (hanya untuk admin)
        btApprovalKredit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                KlikbtApprovalKredit();
            }
        });
    }

    // Fungsi tombol pertama - Pengajuan Kredit
    public void KlikbtPengajuanKredit() {
        Intent i = new Intent(getApplicationContext(), PengajuanKreditActivity.class);

        // Jika pelanggan, kirim idkreditor untuk validasi
        if (session.getUserLevel().equals("pelanggan")) {
            i.putExtra("idkreditor", session.getIdKreditor());
        }

        startActivity(i);
    }

    // Fungsi tombol kedua - Pembayaran Angsuran
    public void KlikbtPembayaranAngsuran() {
        Intent i = new Intent(getApplicationContext(), PembayaranAngsuranActivity.class);

        // Jika pelanggan, hanya bisa lihat pembayaran sendiri
        if (session.getUserLevel().equals("pelanggan")) {
            i.putExtra("idkreditor", session.getIdKreditor());
            i.putExtra("mode", "pelanggan");
        } else {
            // Jika admin, bisa lihat semua pembayaran
            i.putExtra("mode", "admin");
        }

        startActivity(i);
    }

    // Fungsi tombol ketiga - Data Pengajuan Kredit
    public void KlikbtDataPengajuanKredit() {
        Intent i = new Intent(getApplicationContext(), DataPengajuanKreditActivity.class);

        // Jika pelanggan, hanya bisa lihat pengajuan sendiri
        if (session.getUserLevel().equals("pelanggan")) {
            i.putExtra("idkreditor", session.getIdKreditor());
            i.putExtra("mode", "pelanggan");
        } else {
            // Jika admin, bisa lihat semua pengajuan
            i.putExtra("mode", "admin");
        }

        startActivity(i);
    }

    // Fungsi tombol approval - hanya untuk admin
    public void KlikbtApprovalKredit() {
        Intent i = new Intent(getApplicationContext(), DataPengajuanKreditActivity.class);
        i.putExtra("mode", "approval"); // Mode khusus untuk approval
        i.putExtra("admin_id", session.getUsername()); // ID admin yang melakukan approval
        startActivity(i);
    }

    @Override
    public void onBackPressed() {
        // Kembali ke HomeActivity
        Intent i = new Intent(TransaksiActivity.this, HomeActivity.class);
        startActivity(i);
        finish();
    }
}