package com.example.pr_kreditmotor;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {

    Button btDataPetugasHome, btDataMotorHome, btDataKreditorHome, btPengajuanKredit,
            btDataPengajuan, btLogout, btProfilSaya, btTransaksi, btAbout;
    TextView tvWelcome, tvRole;
    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        session = new SessionManager(this);

        initViews();
        setupWelcomeMessage();
        setupRoleBasedUI();
        setupButtonListeners();
    }

    private void initViews() {
        tvWelcome = findViewById(R.id.tvWelcome);
        tvRole = findViewById(R.id.tvRole);

        btDataPetugasHome = findViewById(R.id.btDataPetugasHome);
        btDataMotorHome = findViewById(R.id.btDataMotorHome);
        btDataKreditorHome = findViewById(R.id.btDataKreditorHome);
        btPengajuanKredit = findViewById(R.id.btPengajuanKredit);
        btDataPengajuan = findViewById(R.id.btDataPengajuan);
        btLogout = findViewById(R.id.btLogout);
        btProfilSaya = findViewById(R.id.btProfilSaya);
        btTransaksi = findViewById(R.id.btTransaksi);
        btAbout = findViewById(R.id.btAbout);
    }

    private void setupWelcomeMessage() {
        String welcomeMessage = getString(R.string.welcome_message) + " " + session.getNama() + "!";
        tvWelcome.setText(welcomeMessage);

        // Tampilkan role user menggunakan resource strings
        String roleText = getString(R.string.role_display);
        if (session.getUserLevel().equals("admin")) {
            roleText += getString(R.string.administrator);
        } else {
            roleText += getString(R.string.pelanggan);
        }
        tvRole.setText(roleText);
    }

    private void setupRoleBasedUI() {
        String userLevel = session.getUserLevel();

        if (userLevel.equals("admin")) {
            setupAdminUI();
        } else if (userLevel.equals("pelanggan")) {
            setupPelangganUI();
        }
    }

    private void setupAdminUI() {
        // Tampilkan semua fitur admin
        btDataPetugasHome.setVisibility(View.VISIBLE);
        btDataKreditorHome.setVisibility(View.VISIBLE);
        btDataMotorHome.setText(R.string.data_motor);
        btDataPengajuan.setText(R.string.data_semua_pengajuan);
        btProfilSaya.setVisibility(View.GONE);

        // Atur teks tombol transaksi untuk admin
        btTransaksi.setText(R.string.transaksi_approval_kredit);
    }

    private void setupPelangganUI() {
        // Sembunyikan fitur admin
        btDataPetugasHome.setVisibility(View.GONE);
        btDataKreditorHome.setVisibility(View.GONE);

        // Tampilkan fitur pelanggan
        btDataMotorHome.setText(R.string.lihat_daftar_motor);
        btDataPengajuan.setText(R.string.status_pengajuan_saya);
        btProfilSaya.setVisibility(View.VISIBLE);

        // Atur teks tombol transaksi untuk pelanggan
        btTransaksi.setText(R.string.transaksi_pengajuan_bayar);
    }

    private void setupButtonListeners() {
        // Tombol data master
        btDataPetugasHome.setOnClickListener(v -> KlikbtDataPetugasHome());
        btDataMotorHome.setOnClickListener(v -> KlikbtDataMotorHome());
        btDataKreditorHome.setOnClickListener(v -> KlikbtDataKreditorHome());

        // Tombol transaksi
        btPengajuanKredit.setOnClickListener(v -> KlikbtPengajuanKredit());
        btDataPengajuan.setOnClickListener(v -> KlikbtDataPengajuan());

        // Tombol lainnya
        btTransaksi.setOnClickListener(v -> KlikbtTransaksi());
        btAbout.setOnClickListener(v -> KlikbtAbout());
        btLogout.setOnClickListener(v -> logoutUser());

        // Tombol profil untuk pelanggan
        btProfilSaya.setOnClickListener(v -> {
            Intent i = new Intent(getApplicationContext(), ProfilActivity.class);
            i.putExtra("idkreditor", session.getIdKreditor());
            startActivity(i);
        });
    }

    public void KlikbtDataPetugasHome() {
        Intent i = new Intent(getApplicationContext(), DataPetugasActivity.class);
        startActivity(i);
    }

    public void KlikbtDataMotorHome() {
        Intent i = new Intent(getApplicationContext(), DataMotorActivity.class);
        startActivity(i);
    }

    public void KlikbtDataKreditorHome() {
        if (session.getUserLevel().equals("pelanggan")) {
            Intent i = new Intent(getApplicationContext(), ProfilActivity.class);
            i.putExtra("idkreditor", session.getIdKreditor());
            startActivity(i);
        } else {
            Intent i = new Intent(getApplicationContext(), DataKreditorActivity.class);
            startActivity(i);
        }
    }

    public void KlikbtPengajuanKredit() {
        Intent i = new Intent(getApplicationContext(), PengajuanKreditActivity.class);
        startActivity(i);
    }

    public void KlikbtDataPengajuan() {
        Intent i = new Intent(getApplicationContext(), DataPengajuanKreditActivity.class);
        startActivity(i);
    }

    public void KlikbtTransaksi() {
        Intent i = new Intent(getApplicationContext(), TransaksiActivity.class);
        startActivity(i);
    }

    public void KlikbtAbout() {
        Intent i = new Intent(getApplicationContext(), AboutActivity.class);
        startActivity(i);
    }

    private void logoutUser() {
        session.logoutUser();
        Intent i = new Intent(HomeActivity.this, LoginActivity.class);
        startActivity(i);
        finish();
    }

    @Override
    public void onBackPressed() {
        // Prevent going back to login
        moveTaskToBack(true);
    }
}