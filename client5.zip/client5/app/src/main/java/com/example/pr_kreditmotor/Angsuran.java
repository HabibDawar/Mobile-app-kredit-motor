package com.example.pr_kreditmotor;

import android.os.StrictMode;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class Angsuran {
    // URL disesuaikan dengan folder jskreditmotor
    private String url = "http://10.0.2.2/jskreditmotor/tbangsuran.php";
    // Untuk emulator: 10.0.2.2
    // Untuk device fisik: ganti dengan IP server Anda

    public Angsuran() {
        // Policy untuk mengizinkan network di main thread
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
    }

    public String tampilSemuaAngsuran() {
        try {
            URL link = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) link.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(5000);

            String postData = "action=tampil_semua";

            OutputStream os = conn.getOutputStream();
            os.write(postData.getBytes());
            os.flush();
            os.close();

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            return response.toString();
        } catch (Exception e) {
            e.printStackTrace();
            // Fallback ke data dummy jika server error
            return getDummyData();
        }
    }

    public String tampilAngsuranByKreditor(String idKreditor) {
        try {
            URL link = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) link.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(5000);

            String postData = "action=tampil_by_kreditor&idkreditor=" + idKreditor;

            OutputStream os = conn.getOutputStream();
            os.write(postData.getBytes());
            os.flush();
            os.close();

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            return response.toString();
        } catch (Exception e) {
            e.printStackTrace();
            // Fallback ke data dummy jika server error
            return getDummyDataForKreditor(idKreditor);
        }
    }

    public String bayarAngsuran(String invoice, String username) {
        try {
            URL link = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) link.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(5000);

            String postData = "action=bayar&invoice=" + invoice + "&username=" + username;

            OutputStream os = conn.getOutputStream();
            os.write(postData.getBytes());
            os.flush();
            os.close();

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            // Parse JSON response
            JSONObject jsonResponse = new JSONObject(response.toString());
            if (jsonResponse.getInt("success") == 1) {
                return "Berhasil: " + jsonResponse.getString("message");
            } else {
                return "Gagal: " + jsonResponse.getString("message");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "Error: Gagal terhubung ke server - " + e.getMessage();
        }
    }

    // Method untuk data dummy (fallback)
    private String getDummyData() {
        try {
            JSONArray array = new JSONArray();

            JSONObject item1 = new JSONObject();
            item1.put("invoice", "INV001");
            item1.put("nama_kreditor", "Budi Santoso");
            item1.put("angsuran_ke", "1");
            item1.put("jatuh_tempo", "2024-01-15");
            item1.put("jumlah", "1500000");
            item1.put("status", "belum bayar");
            item1.put("tanggal_bayar", "-");
            array.put(item1);

            JSONObject item2 = new JSONObject();
            item2.put("invoice", "INV002");
            item2.put("nama_kreditor", "Siti Rahayu");
            item2.put("angsuran_ke", "2");
            item2.put("jatuh_tempo", "2024-01-10");
            item2.put("jumlah", "1200000");
            item2.put("status", "lunas");
            item2.put("tanggal_bayar", "2024-01-05");
            array.put(item2);

            return array.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            return "[]";
        }
    }

    private String getDummyDataForKreditor(String idKreditor) {
        try {
            JSONArray array = new JSONArray();

            JSONObject item1 = new JSONObject();
            item1.put("invoice", "INV001");
            item1.put("nama_kreditor", "Anda");
            item1.put("angsuran_ke", "1");
            item1.put("jatuh_tempo", "2024-01-15");
            item1.put("jumlah", "1500000");
            item1.put("status", "belum bayar");
            item1.put("tanggal_bayar", "-");
            array.put(item1);

            return array.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            return "[]";
        }
    }
}