package com.example.pr_kreditmotor;

import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {

    EditText editUsername, editPassword;
    Button btnLogin;
    SessionManager session;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        session = new SessionManager(this);

        // Cek jika sudah login, langsung ke HomeActivity (bukan MainActivity)
        if (session.isLoggedIn()) {
            startActivity(new Intent(LoginActivity.this, HomeActivity.class));
            finish();
        }

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editUsername.getText().toString().trim();
                String password = editPassword.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Username dan password harus diisi", Toast.LENGTH_SHORT).show();
                } else {
                    new LoginTask().execute(username, password);
                }
            }
        });
    }

    private class LoginTask extends AsyncTask<String, Void, String> {
        private String username, password;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(LoginActivity.this);
            progressDialog.setMessage("Login...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        @Override
        protected String doInBackground(String... params) {
            username = params[0];
            password = params[1];

            try {
                Koneksi koneksi = new Koneksi();

                // =============================================
                // PILIH SALAH SATU URL BERIKUT:
                // =============================================

                // OPTION 1: Untuk EMULATOR (10.0.2.2 = localhost)
                String url = "http://10.0.2.2/jskreditmotor/tblogin.php?operasi=login&username=" +
                        username + "&password=" + password;

                // OPTION 2: Untuk DEVICE (ganti dengan IP komputer Anda)
                // String url = "http://192.168.1.5/jskreditmotor/tblogin.php?operasi=login&username=" +
                //             username + "&password=" + password;

                System.out.println("🔗 Login URL: " + url);
                return koneksi.call(url);

            } catch (Exception e) {
                e.printStackTrace();
                return "ERROR: " + e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            progressDialog.dismiss();

            if (result == null) {
                Toast.makeText(LoginActivity.this, "Koneksi gagal - Response null", Toast.LENGTH_SHORT).show();
                return;
            }

            if (result.startsWith("ERROR:")) {
                String errorMsg = result.substring(6);
                Toast.makeText(LoginActivity.this, "Error: " + errorMsg, Toast.LENGTH_LONG).show();
                return;
            }

            if (result.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Response kosong dari server", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                System.out.println("📄 Raw Response: " + result);

                JSONObject jsonObject = new JSONObject(result);
                boolean success = jsonObject.getBoolean("success");
                String message = jsonObject.getString("message");

                if (success) {
                    JSONObject data = jsonObject.getJSONObject("data");
                    String username = data.getString("username");
                    String level = data.getString("level");
                    String idkreditor = data.isNull("idkreditor") ? "0" : data.getString("idkreditor");
                    String nama = data.isNull("nama_kreditor") ? username : data.getString("nama_kreditor");

                    // Create login session
                    session.createLoginSession(username, level, idkreditor, nama);

                    String welcomeMessage = "Login berhasil! Selamat datang " + nama;
                    if (level.equals("pelanggan")) {
                        welcomeMessage += " (Pelanggan)";
                    } else {
                        welcomeMessage += " (Admin)";
                    }

                    Toast.makeText(LoginActivity.this, welcomeMessage, Toast.LENGTH_SHORT).show();

                    // Redirect to HomeActivity
                    Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                    startActivity(intent);
                    finish();

                } else {
                    Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(LoginActivity.this, "Error parsing response: " + e.getMessage(), Toast.LENGTH_LONG).show();
                System.out.println("❌ JSON Parse Error: " + e.getMessage());
                System.out.println("📄 Response yang gagal di-parse: " + result);
            }
        }
    }
}