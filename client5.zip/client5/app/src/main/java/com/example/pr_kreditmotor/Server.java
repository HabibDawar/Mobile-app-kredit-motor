package com.example.pr_kreditmotor;

public class Server {
    public String urlServer = "10.0.2.2";

    public String urlDatabase1() {
        System.out.println("Lokasi Server :" + urlServer);
        return urlServer;
    }
}