package com.example.pr_kreditmotor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class PembayaranAngsuranActivity extends AppCompatActivity {

    // Views
    private TableLayout tbQueryAngsuran;
    private HorizontalScrollView horizontalScrollView;
    private TextView tvTitle, tvRoleInfo, tvTotalAngsuran, tvTerbayar, tvSisa;
    private EditText etSearch;
    private Button btnSearch, btnRefresh, btnBayar, btnExport, btnBack;
    private Spinner spinnerStatus;

    // Data
    private final Angsuran angsuran = new Angsuran();
    private SessionManager session;
    private JSONArray arrayAngsuran;
    private JSONArray originalArrayAngsuran;

    // Role-based
    private String userLevel;
    private String userKreditorId;

    // Selected data for payment
    private String selectedInvoice;
    private double selectedAmount;

    // For button management
    private List<Button> bayarButtons = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pembayaran_angsuran);

        // Initialize session
        session = new SessionManager(this);
        userLevel = session.getUserLevel();
        userKreditorId = session.getIdKreditor();

        initViews();
        setupRoleBasedUI();
        setupSpinner();
        setupButtonListeners();
        loadDataAngsuran();
    }

    private void initViews() {
        // Table and Scroll
        tbQueryAngsuran = findViewById(R.id.tbQueryAngsuran);
        horizontalScrollView = findViewById(R.id.horizontalScrollView);

        // TextViews
        tvTitle = findViewById(R.id.tvTitle);
        tvRoleInfo = findViewById(R.id.tvRoleInfo);
        tvTotalAngsuran = findViewById(R.id.tvTotalAngsuran);
        tvTerbayar = findViewById(R.id.tvTerbayar);
        tvSisa = findViewById(R.id.tvSisa);

        // Search
        etSearch = findViewById(R.id.etSearch);
        btnSearch = findViewById(R.id.btnSearch);

        // Spinner
        spinnerStatus = findViewById(R.id.spinnerStatus);

        // Buttons
        btnRefresh = findViewById(R.id.btnRefresh);
        btnBayar = findViewById(R.id.btnBayar);
        btnExport = findViewById(R.id.btnExport);
        btnBack = findViewById(R.id.btnBack);
    }

    private void setupRoleBasedUI() {
        if (userLevel.equals("admin")) {
            tvTitle.setText("Data Semua Pembayaran Angsuran");
            tvRoleInfo.setText("Mode: Admin - Semua Data");
            tvRoleInfo.setBackgroundColor(Color.parseColor("#E3F2FD"));
            btnBayar.setVisibility(View.GONE);

        } else if (userLevel.equals("pelanggan")) {
            tvTitle.setText("Pembayaran Angsuran Saya");
            tvRoleInfo.setText("Mode: Pelanggan - Data Pribadi");
            tvRoleInfo.setBackgroundColor(Color.parseColor("#E8F5E8"));
            btnBayar.setVisibility(View.VISIBLE);
        }
    }

    private void setupSpinner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.status_angsuran_filter, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerStatus.setAdapter(adapter);

        spinnerStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                filterByStatus(parent.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void setupButtonListeners() {
        btnSearch.setOnClickListener(v -> searchAngsuran());
        btnRefresh.setOnClickListener(v -> refreshData());
        btnBayar.setOnClickListener(v -> showBayarDialog());
        btnExport.setOnClickListener(v -> exportToPDF());
        btnBack.setOnClickListener(v -> onBackPressed());
    }

    private void loadDataAngsuran() {
        try {
            String result;
            if (userLevel.equals("admin")) {
                result = angsuran.tampilSemuaAngsuran();
            } else {
                result = angsuran.tampilAngsuranByKreditor(userKreditorId);
            }

            if (result != null && !result.isEmpty()) {
                arrayAngsuran = new JSONArray(result);
                originalArrayAngsuran = new JSONArray(arrayAngsuran.toString());
                displayAngsuranData(arrayAngsuran);
                updateSummary();
            } else {
                Toast.makeText(this, "Tidak ada data angsuran", Toast.LENGTH_SHORT).show();
                arrayAngsuran = new JSONArray();
                originalArrayAngsuran = new JSONArray();
            }

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading data", Toast.LENGTH_SHORT).show();
            arrayAngsuran = new JSONArray();
            originalArrayAngsuran = new JSONArray();
        }
    }

    private void displayAngsuranData(JSONArray dataArray) {
        // Clear existing table
        tbQueryAngsuran.removeAllViews();
        bayarButtons.clear();

        // Create header row dengan style biru
        TableRow headerRow = new TableRow(this);
        headerRow.setBackgroundColor(Color.parseColor("#1976D2"));

        // Column configuration
        String[] headers;
        int[] minWidths;

        if (userLevel.equals("admin")) {
            headers = new String[]{"No", "Invoice", "Kreditor", "Angsuran Ke", "Jatuh Tempo", "Jumlah", "Status", "Tanggal Bayar", "Aksi"};
            minWidths = new int[]{
                    dpToPx(50),   // No
                    dpToPx(120),  // Invoice
                    dpToPx(150),  // Kreditor
                    dpToPx(100),  // Angsuran Ke
                    dpToPx(110),  // Jatuh Tempo
                    dpToPx(120),  // Jumlah
                    dpToPx(100),  // Status
                    dpToPx(110),  // Tanggal Bayar
                    dpToPx(100)   // Aksi
            };
        } else {
            headers = new String[]{"No", "Invoice", "Angsuran Ke", "Jatuh Tempo", "Jumlah", "Status", "Tanggal Bayar", "Aksi"};
            minWidths = new int[]{
                    dpToPx(50),   // No
                    dpToPx(120),  // Invoice
                    dpToPx(100),  // Angsuran Ke
                    dpToPx(110),  // Jatuh Tempo
                    dpToPx(120),  // Jumlah
                    dpToPx(100),  // Status
                    dpToPx(110),  // Tanggal Bayar
                    dpToPx(100)   // Aksi
            };
        }

        for (int i = 0; i < headers.length; i++) {
            TextView headerView = createHeaderTextView(headers[i]);
            TableRow.LayoutParams params = new TableRow.LayoutParams(
                    minWidths[i],
                    TableRow.LayoutParams.WRAP_CONTENT
            );
            headerView.setLayoutParams(params);
            headerRow.addView(headerView);
        }

        tbQueryAngsuran.addView(headerRow);

        try {
            if (dataArray.length() == 0) {
                TableRow emptyRow = new TableRow(this);
                int spanCount = userLevel.equals("admin") ? 9 : 8;

                TextView emptyText = new TextView(this);
                emptyText.setText("Tidak ada data angsuran");
                emptyText.setTextColor(Color.GRAY);
                emptyText.setTypeface(Typeface.DEFAULT_BOLD);
                emptyText.setGravity(Gravity.CENTER);
                emptyText.setPadding(dpToPx(16), dpToPx(40), dpToPx(16), dpToPx(40));

                TableRow.LayoutParams params = new TableRow.LayoutParams(
                        TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.WRAP_CONTENT
                );
                params.span = spanCount;
                emptyText.setLayoutParams(params);
                emptyRow.addView(emptyText);
                tbQueryAngsuran.addView(emptyRow);
                return;
            }

            for (int i = 0; i < dataArray.length(); i++) {
                JSONObject jsonChildNode = dataArray.getJSONObject(i);
                String invoice = jsonChildNode.optString("invoice", "-");
                String namaKreditor = jsonChildNode.optString("nama_kreditor", "-");
                String angsuranKe = jsonChildNode.optString("angsuran_ke", "-");
                String jatuhTempo = jsonChildNode.optString("jatuh_tempo", "-");
                String jumlah = jsonChildNode.optString("jumlah", "0");
                String status = jsonChildNode.optString("status", "-");
                String tanggalBayar = jsonChildNode.optString("tanggal_bayar", "-");

                TableRow dataRow = new TableRow(this);
                dataRow.setBackgroundColor(i % 2 == 0 ? Color.parseColor("#FFFFFF") : Color.parseColor("#F5F5F5"));
                dataRow.setMinimumHeight(dpToPx(45));

                // No
                addDataCell(dataRow, String.valueOf(i + 1), minWidths[0], Gravity.CENTER);

                // Invoice
                addDataCell(dataRow, invoice, minWidths[1], Gravity.CENTER);

                // Kreditor (hanya untuk admin)
                if (userLevel.equals("admin")) {
                    addDataCell(dataRow, namaKreditor, minWidths[2], Gravity.START);
                }

                // Angsuran Ke
                int angsuranKeIndex = userLevel.equals("admin") ? 3 : 2;
                addDataCell(dataRow, angsuranKe, minWidths[angsuranKeIndex], Gravity.CENTER);

                // Jatuh Tempo
                int jatuhTempoIndex = userLevel.equals("admin") ? 4 : 3;
                String shortJatuhTempo = jatuhTempo.length() > 10 ? jatuhTempo.substring(0, 10) : jatuhTempo;
                addDataCell(dataRow, shortJatuhTempo, minWidths[jatuhTempoIndex], Gravity.CENTER);

                // Jumlah
                int jumlahIndex = userLevel.equals("admin") ? 5 : 4;
                addDataCell(dataRow, "Rp " + formatNumber(jumlah), minWidths[jumlahIndex], Gravity.END);

                // Status
                int statusIndex = userLevel.equals("admin") ? 6 : 5;
                TextView statusView = createDataCell(getStatusDisplayText(status), minWidths[statusIndex], Gravity.CENTER);
                setStatusStyle(statusView, status);
                dataRow.addView(statusView);

                // Tanggal Bayar
                int tanggalBayarIndex = userLevel.equals("admin") ? 7 : 6;
                String displayTanggalBayar = "-";
                if (!tanggalBayar.equals("null") && !tanggalBayar.isEmpty() && !tanggalBayar.equals("-")) {
                    displayTanggalBayar = tanggalBayar.length() > 10 ? tanggalBayar.substring(0, 10) : tanggalBayar;
                }
                addDataCell(dataRow, displayTanggalBayar, minWidths[tanggalBayarIndex], Gravity.CENTER);

                // Action buttons
                int aksiIndex = userLevel.equals("admin") ? 8 : 7;
                if (userLevel.equals("pelanggan") && (status.equals("belum bayar") || status.equals("pending") || status.equals("terlambat"))) {
                    Button btnBayarItem = createActionButton("BAYAR", Color.parseColor("#2196F3"));
                    btnBayarItem.setTag(invoice + "|" + jumlah);
                    btnBayarItem.setOnClickListener(v -> {
                        String[] tagParts = v.getTag().toString().split("\\|");
                        selectedInvoice = tagParts[0];
                        selectedAmount = Double.parseDouble(tagParts[1]);
                        showBayarDialog();
                    });

                    TableRow.LayoutParams actionParams = new TableRow.LayoutParams(
                            minWidths[aksiIndex],
                            TableRow.LayoutParams.WRAP_CONTENT
                    );
                    btnBayarItem.setLayoutParams(actionParams);
                    dataRow.addView(btnBayarItem);
                    bayarButtons.add(btnBayarItem);
                } else {
                    addDataCell(dataRow, "-", minWidths[aksiIndex], Gravity.CENTER);
                }

                tbQueryAngsuran.addView(dataRow);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error displaying data", Toast.LENGTH_SHORT).show();
        }
    }

    // Helper methods untuk tampilan tabel
    private void addDataCell(TableRow row, String text, int minWidth, int gravity) {
        TextView textView = createDataCell(text, minWidth, gravity);
        row.addView(textView);
    }

    private TextView createDataCell(String text, int minWidth, int gravity) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(dpToPx(8), dpToPx(12), dpToPx(8), dpToPx(12));
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        textView.setGravity(gravity);
        textView.setSingleLine(true);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setTextColor(Color.parseColor("#333333"));
        textView.setTypeface(Typeface.DEFAULT);

        TableRow.LayoutParams params = new TableRow.LayoutParams(
                minWidth,
                TableRow.LayoutParams.WRAP_CONTENT
        );
        textView.setLayoutParams(params);

        return textView;
    }

    private TextView createHeaderTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextColor(Color.WHITE);
        textView.setPadding(dpToPx(8), dpToPx(12), dpToPx(8), dpToPx(12));
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setGravity(Gravity.CENTER);
        textView.setSingleLine(true);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setBackgroundColor(Color.parseColor("#1976D2"));
        return textView;
    }

    private Button createActionButton(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        button.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setAllCaps(false);

        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadius(dpToPx(4));
        shape.setColor(color);
        button.setBackground(shape);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                TableRow.LayoutParams.WRAP_CONTENT,
                dpToPx(36)
        );
        params.setMargins(dpToPx(2), 0, dpToPx(2), 0);
        button.setLayoutParams(params);

        return button;
    }

    private void setStatusStyle(TextView statusView, String status) {
        GradientDrawable statusBackground = new GradientDrawable();
        statusBackground.setShape(GradientDrawable.RECTANGLE);
        statusBackground.setCornerRadius(dpToPx(4));
        statusBackground.setStroke(dpToPx(1), Color.parseColor("#E0E0E0"));

        switch (status.toLowerCase()) {
            case "lunas":
                statusBackground.setColor(Color.parseColor("#E8F5E8"));
                statusView.setTextColor(Color.parseColor("#2E7D32"));
                statusView.setTypeface(Typeface.DEFAULT_BOLD);
                break;
            case "terlambat":
            case "lewati jatuh tempo":
                statusBackground.setColor(Color.parseColor("#FFEBEE"));
                statusView.setTextColor(Color.parseColor("#C62828"));
                statusView.setTypeface(Typeface.DEFAULT_BOLD);
                break;
            case "belum bayar":
            case "pending":
                statusBackground.setColor(Color.parseColor("#FFF3E0"));
                statusView.setTextColor(Color.parseColor("#EF6C00"));
                statusView.setTypeface(Typeface.DEFAULT_BOLD);
                break;
            default:
                statusBackground.setColor(Color.parseColor("#F5F5F5"));
                statusView.setTextColor(Color.parseColor("#666666"));
        }

        statusView.setBackground(statusBackground);
        statusView.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
    }

    private String getStatusDisplayText(String status) {
        switch (status.toLowerCase()) {
            case "lunas": return "LUNAS";
            case "terlambat":
            case "lewati jatuh tempo": return "TERLAMBAT";
            case "belum bayar":
            case "pending": return "BELUM BAYAR";
            default: return status.toUpperCase();
        }
    }

    private int dpToPx(int dp) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp,
                getResources().getDisplayMetrics()
        );
    }

    private String formatNumber(String number) {
        try {
            // Remove any existing formatting
            String cleanAmount = number.replaceAll("[^\\d]", "");
            long value = Long.parseLong(cleanAmount);
            return String.format("%,d", value).replace(',', '.');
        } catch (NumberFormatException e) {
            return number;
        }
    }

    private void updateSummary() {
        try {
            double totalAngsuran = 0;
            double terbayar = 0;
            double sisa = 0;

            for (int i = 0; i < arrayAngsuran.length(); i++) {
                JSONObject angsuranObj = arrayAngsuran.getJSONObject(i);
                String jumlahStr = angsuranObj.optString("jumlah", "0");
                String status = angsuranObj.optString("status", "");

                // Clean the amount string
                String cleanJumlah = jumlahStr.replaceAll("[^\\d]", "");
                double jumlah = Double.parseDouble(cleanJumlah);

                totalAngsuran += jumlah;
                if (status.equalsIgnoreCase("lunas")) {
                    terbayar += jumlah;
                } else {
                    sisa += jumlah;
                }
            }

            NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
            format.setMaximumFractionDigits(0);

            tvTotalAngsuran.setText(format.format(totalAngsuran));
            tvTerbayar.setText(format.format(terbayar));
            tvSisa.setText(format.format(sisa));

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void searchAngsuran() {
        String searchText = etSearch.getText().toString().trim().toLowerCase();

        if (TextUtils.isEmpty(searchText)) {
            displayAngsuranData(originalArrayAngsuran);
            updateSummary();
            return;
        }

        try {
            JSONArray filteredArray = new JSONArray();

            for (int i = 0; i < originalArrayAngsuran.length(); i++) {
                JSONObject angsuranObj = originalArrayAngsuran.getJSONObject(i);
                String invoice = angsuranObj.optString("invoice", "").toLowerCase();
                String namaKreditor = angsuranObj.optString("nama_kreditor", "").toLowerCase();

                if (invoice.contains(searchText) || namaKreditor.contains(searchText)) {
                    filteredArray.put(angsuranObj);
                }
            }

            if (filteredArray.length() > 0) {
                arrayAngsuran = filteredArray;
                displayAngsuranData(filteredArray);
                updateSummary();
                Toast.makeText(this, "Ditemukan " + filteredArray.length() + " data", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Data tidak ditemukan", Toast.LENGTH_SHORT).show();
                displayAngsuranData(originalArrayAngsuran);
                updateSummary();
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error searching data", Toast.LENGTH_SHORT).show();
        }
    }

    private void filterByStatus(String status) {
        if (status.equals("Semua Status")) {
            displayAngsuranData(originalArrayAngsuran);
            updateSummary();
            return;
        }

        try {
            JSONArray filteredArray = new JSONArray();

            for (int i = 0; i < originalArrayAngsuran.length(); i++) {
                JSONObject angsuranObj = originalArrayAngsuran.getJSONObject(i);
                String angsuranStatus = angsuranObj.optString("status", "");

                if (angsuranStatus.equalsIgnoreCase(status)) {
                    filteredArray.put(angsuranObj);
                }
            }

            arrayAngsuran = filteredArray;
            displayAngsuranData(filteredArray);
            updateSummary();

            if (filteredArray.length() == 0) {
                Toast.makeText(this, "Tidak ada data dengan status " + status, Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void refreshData() {
        etSearch.setText("");
        spinnerStatus.setSelection(0);
        loadDataAngsuran();
        Toast.makeText(this, "Data diperbarui", Toast.LENGTH_SHORT).show();
    }

    private void showBayarDialog() {
        if (selectedInvoice == null || selectedInvoice.isEmpty()) {
            Toast.makeText(this, "Pilih angsuran yang akan dibayar", Toast.LENGTH_SHORT).show();
            return;
        }

        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
        format.setMaximumFractionDigits(0);

        new AlertDialog.Builder(this)
                .setTitle("Konfirmasi Pembayaran")
                .setMessage("Bayar angsuran untuk invoice: " + selectedInvoice +
                        "\nJumlah: " + format.format(selectedAmount))
                .setPositiveButton("Bayar", (dialog, which) -> {
                    prosesPembayaran();
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void prosesPembayaran() {
        if (selectedInvoice == null || selectedInvoice.isEmpty()) {
            Toast.makeText(this, "Pilih angsuran terlebih dahulu", Toast.LENGTH_SHORT).show();
            return;
        }

        String result = angsuran.bayarAngsuran(selectedInvoice, session.getUsername());
        Toast.makeText(this, result, Toast.LENGTH_SHORT).show();

        if (result.contains("Berhasil") || result.contains("sukses")) {
            refreshData();
            selectedInvoice = null;
            selectedAmount = 0;
        }
    }

    private void exportToPDF() {
        Toast.makeText(this, "Fitur export PDF akan diimplementasikan", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}