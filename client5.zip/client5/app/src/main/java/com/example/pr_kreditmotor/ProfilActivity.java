package com.example.pr_kreditmotor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ProfilActivity extends AppCompatActivity {

    // Views dengan inisialisasi null untuk menghindari NPE
    private TextView tvTitle = null;
    private TextView tvRoleInfo = null;
    private TextView tvUserId = null;
    private TextView tvUsername = null;
    private TextView tvUserLevel = null;
    private EditText etNama = null;
    private EditText etAlamat = null;
    private EditText etTelepon = null;
    private EditText etEmail = null;
    private EditText etPassword = null;
    private EditText etConfirmPassword = null;
    private Button btnUpdate = null;
    private Button btnChangePassword = null;
    private Button btnBack = null;
    private LinearLayout layoutPelanggan = null;
    private LinearLayout layoutAdmin = null;

    // Data
    private SessionManager session;
    private Kreditor kreditor = new Kreditor();
    private Petugas petugas = new Petugas();

    // User data dengan default values
    private String userLevel = "pelanggan";
    private String userId = "";
    private String username = "";

    private static final String TAG = "ProfilActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);

        Log.d(TAG, "onCreate: Starting ProfilActivity");

        // Initialize session dengan protection
        try {
            session = new SessionManager(this);
            userLevel = session.getUserLevel();
            userId = session.getIdKreditor();
            username = session.getUsername();
            Log.d(TAG, "Session loaded - Level: " + userLevel + ", ID: " + userId + ", Username: " + username);
        } catch (Exception e) {
            Log.e(TAG, "Session init error: " + e.getMessage());
            Toast.makeText(this, "Error memuat session", Toast.LENGTH_SHORT).show();
        }

        // Handle null values
        if (userLevel == null || userLevel.isEmpty()) {
            userLevel = "pelanggan";
            Log.w(TAG, "userLevel is null, using default: pelanggan");
        }
        if (userId == null) {
            userId = "";
            Log.w(TAG, "userId is null, using empty string");
        }
        if (username == null) {
            username = "";
            Log.w(TAG, "username is null, using empty string");
        }

        // Initialize views dengan protection
        initializeViewsSafe();

        // Setup UI
        setupRoleBasedUISafe();
        setupButtonListenersSafe();

        // Load data di background
        loadUserDataSafe();
    }

    /**
     * INISIALISASI VIEWS YANG AMAN - dengan try-catch individual
     */
    private void initializeViewsSafe() {
        Log.d(TAG, "Initializing views...");

        try {
            // TextViews
            tvTitle = safeFindViewById(R.id.tvTitle, "tvTitle");
            tvRoleInfo = safeFindViewById(R.id.tvRoleInfo, "tvRoleInfo");
            tvUserId = safeFindViewById(R.id.tvUserId, "tvUserId");
            tvUsername = safeFindViewById(R.id.tvUsername, "tvUsername");
            tvUserLevel = safeFindViewById(R.id.tvUserLevel, "tvUserLevel");

            // EditTexts
            etNama = safeFindViewById(R.id.etNama, "etNama");
            etAlamat = safeFindViewById(R.id.etAlamat, "etAlamat");
            etTelepon = safeFindViewById(R.id.etTelepon, "etTelepon");
            etEmail = safeFindViewById(R.id.etEmail, "etEmail");
            etPassword = safeFindViewById(R.id.etPassword, "etPassword");
            etConfirmPassword = safeFindViewById(R.id.etConfirmPassword, "etConfirmPassword");

            // Buttons
            btnUpdate = safeFindViewById(R.id.btnUpdate, "btnUpdate");
            btnChangePassword = safeFindViewById(R.id.btnChangePassword, "btnChangePassword");
            btnBack = safeFindViewById(R.id.btnBack, "btnBack");

            // Layouts
            layoutPelanggan = safeFindViewById(R.id.layoutPelanggan, "layoutPelanggan");
            layoutAdmin = safeFindViewById(R.id.layoutAdmin, "layoutAdmin");

            Log.d(TAG, "View initialization completed");

        } catch (Exception e) {
            Log.e(TAG, "Critical error in view initialization: " + e.getMessage());
            Toast.makeText(this, "Error inisialisasi layout profil", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Helper method untuk findViewById yang aman dengan logging
     */
    private <T extends View> T safeFindViewById(int id, String viewName) {
        try {
            T view = findViewById(id);
            if (view == null) {
                Log.w(TAG, "View not found: " + viewName + " (ID: " + id + ")");
            } else {
                Log.d(TAG, "View found: " + viewName);
            }
            return view;
        } catch (Exception e) {
            Log.e(TAG, "Error finding view " + viewName + ": " + e.getMessage());
            return null;
        }
    }

    /**
     * SETUP ROLE BASED UI YANG AMAN - tidak akan crash
     */
    @SuppressLint("SetTextI18n")
    private void setupRoleBasedUISafe() {
        try {
            Log.d(TAG, "Setting up UI for role: " + userLevel);

            if (userLevel.equals("admin")) {
                // Setup untuk admin
                if (tvTitle != null) {
                    tvTitle.setText("Profil Admin");
                } else {
                    Log.w(TAG, "tvTitle is null - cannot set text");
                }

                if (tvRoleInfo != null) {
                    tvRoleInfo.setText("Mode: Administrator");
                    tvRoleInfo.setBackgroundColor(Color.parseColor("#E3F2FD"));
                } else {
                    Log.w(TAG, "tvRoleInfo is null - cannot set role info");
                }

                // Tampilkan layout admin, sembunyikan pelanggan
                if (layoutAdmin != null) {
                    layoutAdmin.setVisibility(View.VISIBLE);
                } else {
                    Log.w(TAG, "layoutAdmin is null - cannot show");
                }

                if (layoutPelanggan != null) {
                    layoutPelanggan.setVisibility(View.GONE);
                } else {
                    Log.w(TAG, "layoutPelanggan is null - cannot hide");
                }

            } else {
                // Setup untuk pelanggan (default)
                if (tvTitle != null) {
                    tvTitle.setText("Profil Pelanggan");
                }

                if (tvRoleInfo != null) {
                    tvRoleInfo.setText("Mode: Pelanggan");
                    tvRoleInfo.setBackgroundColor(Color.parseColor("#E8F5E8"));
                }

                // Tampilkan layout pelanggan, sembunyikan admin
                if (layoutAdmin != null) {
                    layoutAdmin.setVisibility(View.GONE);
                }

                if (layoutPelanggan != null) {
                    layoutPelanggan.setVisibility(View.VISIBLE);
                }
            }

            // Set data dasar dengan null check
            if (tvUserId != null) {
                tvUserId.setText("ID: " + (!TextUtils.isEmpty(userId) ? userId : "N/A"));
            }

            if (tvUsername != null) {
                tvUsername.setText("Username: " + (!TextUtils.isEmpty(username) ? username : "N/A"));
            }

            if (tvUserLevel != null) {
                tvUserLevel.setText("Role: " + userLevel);
            }

            Log.d(TAG, "UI setup completed successfully");

        } catch (Exception e) {
            Log.e(TAG, "Error in setupRoleBasedUI: " + e.getMessage());
            // JANGAN crash, continue dengan state default
        }
    }

    /**
     * SETUP BUTTON LISTENERS YANG AMAN
     */
    private void setupButtonListenersSafe() {
        // Button Update
        if (btnUpdate != null) {
            btnUpdate.setOnClickListener(v -> {
                Log.d(TAG, "Update button clicked");
                updateProfile();
            });
        } else {
            Log.w(TAG, "btnUpdate is null - button listener not set");
        }

        // Button Change Password
        if (btnChangePassword != null) {
            btnChangePassword.setOnClickListener(v -> {
                Log.d(TAG, "Change password button clicked");
                changePassword();
            });
        } else {
            Log.w(TAG, "btnChangePassword is null - button listener not set");
        }

        // Button Back
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> {
                Log.d(TAG, "Back button clicked");
                onBackPressed();
            });
        } else {
            Log.w(TAG, "btnBack is null - button listener not set");
        }

        Log.d(TAG, "Button listeners setup completed");
    }

    /**
     * LOAD USER DATA YANG AMAN - di background thread
     */
    private void loadUserDataSafe() {
        Log.d(TAG, "Starting to load user data...");

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (userLevel.equals("admin")) {
                        Log.d(TAG, "Loading petugas data for admin");
                        loadPetugasData();
                    } else {
                        Log.d(TAG, "Loading kreditor data for pelanggan");
                        loadKreditorData();
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error in loadUserData: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(ProfilActivity.this, "Error memuat data pengguna", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }).start();
    }

    /**
     * LOAD DATA KREDITOR YANG AMAN
     */
    private void loadKreditorData() {
        Log.d(TAG, "loadKreditorData called with userId: " + userId);

        // Validasi userId
        if (TextUtils.isEmpty(userId) || userId.equals("0")) {
            Log.e(TAG, "Invalid userId for kreditor: " + userId);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(ProfilActivity.this, "ID Kreditor tidak valid", Toast.LENGTH_SHORT).show();
                }
            });
            return;
        }

        try {
            String result = kreditor.select_by_Idkreditor(userId);
            Log.d(TAG, "Kreditor API Response: " + result);

            if (result != null && !result.isEmpty()) {
                // Parse sebagai JSONObject
                JSONObject jsonResponse = new JSONObject(result);

                if (jsonResponse.getBoolean("success")) {
                    JSONArray dataArray = jsonResponse.getJSONArray("data");
                    if (dataArray.length() > 0) {
                        JSONObject data = dataArray.getJSONObject(0);

                        final String nama = data.optString("nama", "");
                        final String alamat = data.optString("alamat", "");
                        final String telepon = data.optString("telp", ""); // Field di PHP adalah 'telp'
                        final String email = data.optString("email", "");

                        Log.d(TAG, "Loaded kreditor data - Nama: " + nama + ", Alamat: " + alamat);

                        // Update UI di main thread
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    if (etNama != null) etNama.setText(nama);
                                    if (etAlamat != null) etAlamat.setText(alamat);
                                    if (etTelepon != null) etTelepon.setText(telepon);
                                    if (etEmail != null) etEmail.setText(email);

                                    Log.d(TAG, "Kreditor data displayed successfully");
                                } catch (Exception e) {
                                    Log.e(TAG, "Error updating UI with kreditor data: " + e.getMessage());
                                }
                            }
                        });

                    } else {
                        Log.w(TAG, "No data found in kreditor response");
                        showErrorOnUI("Data kreditor tidak ditemukan");
                    }
                } else {
                    String errorMessage = jsonResponse.optString("message", "Gagal memuat data kreditor");
                    Log.e(TAG, "API Error: " + errorMessage);
                    showErrorOnUI(errorMessage);
                }
            } else {
                Log.e(TAG, "Empty response from kreditor API");
                showErrorOnUI("Response kosong dari server");
            }
        } catch (JSONException e) {
            Log.e(TAG, "JSON Error in loadKreditorData: " + e.getMessage());
            showErrorOnUI("Error parsing data kreditor");
        } catch (Exception e) {
            Log.e(TAG, "Error in loadKreditorData: " + e.getMessage());
            showErrorOnUI("Error memuat data kreditor");
        }
    }

    /**
     * LOAD DATA PETUGAS YANG AMAN
     */
    private void loadPetugasData() {
        Log.d(TAG, "loadPetugasData called with username: " + username);

        if (TextUtils.isEmpty(username)) {
            Log.e(TAG, "Invalid username for petugas");
            showErrorOnUI("Username tidak valid");
            return;
        }

        try {
            String result = petugas.select_by_username(username);
            Log.d(TAG, "Petugas API Response: " + result);

            if (result != null && !result.isEmpty()) {
                JSONObject jsonResponse = new JSONObject(result);

                if (jsonResponse.getBoolean("success")) {
                    JSONArray dataArray = jsonResponse.getJSONArray("data");
                    if (dataArray.length() > 0) {
                        JSONObject data = dataArray.getJSONObject(0);

                        final String nama = data.optString("nama", "");
                        final String email = data.optString("email", "");

                        Log.d(TAG, "Loaded petugas data - Nama: " + nama);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    if (etNama != null) etNama.setText(nama);
                                    if (etEmail != null) etEmail.setText(email);

                                    // Untuk admin, sembunyikan field yang tidak diperlukan
                                    if (etAlamat != null) etAlamat.setVisibility(View.GONE);
                                    if (etTelepon != null) etTelepon.setVisibility(View.GONE);

                                    // Sembunyikan label yang tidak diperlukan
                                    View tvAlamat = findViewById(R.id.tvAlamat);
                                    View tvTelepon = findViewById(R.id.tvTelepon);
                                    if (tvAlamat != null) tvAlamat.setVisibility(View.GONE);
                                    if (tvTelepon != null) tvTelepon.setVisibility(View.GONE);

                                    Log.d(TAG, "Petugas data displayed successfully");
                                } catch (Exception e) {
                                    Log.e(TAG, "Error updating UI with petugas data: " + e.getMessage());
                                }
                            }
                        });

                    } else {
                        Log.w(TAG, "No data found in petugas response");
                        showErrorOnUI("Data petugas tidak ditemukan");
                    }
                } else {
                    String errorMessage = jsonResponse.optString("message", "Gagal memuat data petugas");
                    Log.e(TAG, "API Error: " + errorMessage);
                    showErrorOnUI(errorMessage);
                }
            } else {
                Log.e(TAG, "Empty response from petugas API");
                showErrorOnUI("Response kosong dari server");
            }
        } catch (JSONException e) {
            Log.e(TAG, "JSON Error in loadPetugasData: " + e.getMessage());
            showErrorOnUI("Error parsing data petugas");
        } catch (Exception e) {
            Log.e(TAG, "Error in loadPetugasData: " + e.getMessage());
            showErrorOnUI("Error memuat data petugas");
        }
    }

    /**
     * HELPER UNTUK MENAMPILKAN ERROR DI UI THREAD
     */
    private void showErrorOnUI(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Toast.makeText(ProfilActivity.this, message, Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Log.e(TAG, "Error showing toast: " + e.getMessage());
                }
            }
        });
    }

    /**
     * UPDATE PROFILE YANG AMAN
     */
    private void updateProfile() {
        Log.d(TAG, "updateProfile called");

        if (etNama == null) {
            Toast.makeText(this, "Error: Form tidak tersedia", Toast.LENGTH_SHORT).show();
            return;
        }

        String nama = etNama.getText().toString().trim();
        String email = etEmail != null ? etEmail.getText().toString().trim() : "";

        if (TextUtils.isEmpty(nama)) {
            Toast.makeText(this, "Nama tidak boleh kosong", Toast.LENGTH_SHORT).show();
            return;
        }

        if (userLevel.equals("admin")) {
            updatePetugasProfile(nama, email);
        } else {
            updateKreditorProfile(nama, email);
        }
    }

    /**
     * UPDATE PROFILE KREDITOR YANG AMAN
     */
    private void updateKreditorProfile(String nama, String email) {
        Log.d(TAG, "updateKreditorProfile called");

        // Validasi field yang diperlukan untuk kreditor
        if (etAlamat == null || etTelepon == null) {
            Toast.makeText(this, "Error: Form alamat/telepon tidak tersedia", Toast.LENGTH_SHORT).show();
            return;
        }

        String alamat = etAlamat.getText().toString().trim();
        String telepon = etTelepon.getText().toString().trim();

        if (TextUtils.isEmpty(alamat)) {
            Toast.makeText(this, "Alamat tidak boleh kosong", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(telepon)) {
            Toast.makeText(this, "Telepon tidak boleh kosong", Toast.LENGTH_SHORT).show();
            return;
        }

        // Jalankan di background thread
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final String result = kreditor.update_kreditor(userId, nama, alamat, telepon, email);
                    Log.d(TAG, "Update kreditor result: " + result);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Toast.makeText(ProfilActivity.this, result, Toast.LENGTH_SHORT).show();

                                if (result.contains("Berhasil") || result.contains("sukses") || result.contains("success")) {
                                    Log.d(TAG, "Kreditor profile updated successfully");
                                    // Update session jika perlu
                                    updateSessionIfNeeded(nama, email);
                                }
                            } catch (Exception e) {
                                Log.e(TAG, "Error showing update result: " + e.getMessage());
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "Error in updateKreditorProfile: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(ProfilActivity.this, "Error update profil: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }).start();
    }

    /**
     * UPDATE PROFILE PETUGAS YANG AMAN
     */
    private void updatePetugasProfile(String nama, String email) {
        Log.d(TAG, "updatePetugasProfile called");

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final String result = petugas.update_petugas_profil(username, nama, email);
                    Log.d(TAG, "Update petugas result: " + result);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Toast.makeText(ProfilActivity.this, result, Toast.LENGTH_SHORT).show();

                                if (result.contains("Berhasil") || result.contains("sukses") || result.contains("success")) {
                                    Log.d(TAG, "Petugas profile updated successfully");
                                    // Update session jika perlu
                                    updateSessionIfNeeded(nama, email);
                                }
                            } catch (Exception e) {
                                Log.e(TAG, "Error showing update result: " + e.getMessage());
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "Error in updatePetugasProfile: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(ProfilActivity.this, "Error update profil: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }).start();
    }

    /**
     * UPDATE SESSION JIKA PERLU
     */
    private void updateSessionIfNeeded(String nama, String email) {
        try {
            if (session != null) {
                // Coba update session jika method tersedia
                try {
                    session.updateUserProfile(nama, email);
                    Log.d(TAG, "Session updated with new profile data");
                } catch (Exception e) {
                    // Method tidak ada, skip saja - ini normal
                    Log.d(TAG, "updateUserProfile method not available in session");
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error updating session: " + e.getMessage());
        }
    }

    /**
     * CHANGE PASSWORD YANG AMAN
     */
    private void changePassword() {
        Log.d(TAG, "changePassword called");

        if (etPassword == null || etConfirmPassword == null) {
            Toast.makeText(this, "Error: Form password tidak tersedia", Toast.LENGTH_SHORT).show();
            return;
        }

        String password = etPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();

        if (TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Password baru tidak boleh kosong", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 6) {
            Toast.makeText(this, "Password minimal 6 karakter", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Konfirmasi password tidak cocok", Toast.LENGTH_SHORT).show();
            return;
        }

        // Tampilkan konfirmasi
        new AlertDialog.Builder(this)
                .setTitle("Konfirmasi Ganti Password")
                .setMessage("Apakah Anda yakin ingin mengganti password?")
                .setPositiveButton("Ya", (dialog, which) -> {
                    prosesGantiPassword(password);
                })
                .setNegativeButton("Tidak", null)
                .show();
    }

    /**
     * PROSES GANTI PASSWORD YANG AMAN
     */
    private void prosesGantiPassword(String newPassword) {
        Log.d(TAG, "prosesGantiPassword called");

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String result;
                    if (userLevel.equals("admin")) {
                        result = petugas.update_password(username, newPassword);
                    } else {
                        result = kreditor.update_password(userId, newPassword);
                    }

                    Log.d(TAG, "Change password result: " + result);
                    final String finalResult = result;

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Toast.makeText(ProfilActivity.this, finalResult, Toast.LENGTH_SHORT).show();

                                if (finalResult.contains("Berhasil") || finalResult.contains("sukses") || finalResult.contains("success")) {
                                    // Clear password fields
                                    if (etPassword != null) etPassword.setText("");
                                    if (etConfirmPassword != null) etConfirmPassword.setText("");
                                    Log.d(TAG, "Password changed successfully");
                                }
                            } catch (Exception e) {
                                Log.e(TAG, "Error showing password change result: " + e.getMessage());
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "Error in prosesGantiPassword: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(ProfilActivity.this, "Error ganti password: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }).start();
    }

    @Override
    public void onBackPressed() {
        Log.d(TAG, "onBackPressed: Finishing activity");
        super.onBackPressed();
        finish();
    }

    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy: Activity destroyed");
        super.onDestroy();
    }
}