package com.example.pr_kreditmotor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DataPengajuanKreditActivity extends AppCompatActivity {

    // Views
    private TableLayout tbQueryKredit;
    private HorizontalScrollView horizontalScrollView;
    private TextView tvTitle, tvRoleInfo;
    private EditText etSearch;
    private Button btnSearch, btnRefresh, btnApproveAll, btnRejectAll, btnExport, btnBack;
    private Spinner spinnerStatus;

    // Data
    private Kredit kredit = new Kredit();
    private SessionManager session;
    private JSONArray arrayKredit;
    private JSONArray originalArrayKredit;

    // Role-based
    private String userLevel;
    private String userKreditorId;
    private String mode; // "admin", "pelanggan", "approval"

    // For approval system
    private Map<Integer, String> selectedKreditMap = new HashMap<>();
    private ArrayList<Button> buttonApproveList = new ArrayList<>();
    private ArrayList<Button> buttonRejectList = new ArrayList<>();

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_pengajuan_kredit);

        // Initialize session
        session = new SessionManager(this);
        userLevel = session.getUserLevel();
        userKreditorId = session.getIdKreditor();

        // Get intent mode
        Intent intent = getIntent();
        mode = intent.getStringExtra("mode");
        if (mode == null) {
            mode = userLevel.equals("admin") ? "admin" : "pelanggan";
        }

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        initViews();
        setupRoleBasedUI();
        setupSpinner();
        setupButtonListeners();
        loadDataKredit();
    }

    private void initViews() {
        // Table and Scroll
        tbQueryKredit = findViewById(R.id.tbQueryKredit);
        horizontalScrollView = findViewById(R.id.horizontalScrollView);

        // TextViews
        tvTitle = findViewById(R.id.tvTitle);
        tvRoleInfo = findViewById(R.id.tvRoleInfo);

        // Search
        etSearch = findViewById(R.id.etSearch);
        btnSearch = findViewById(R.id.btnSearch);

        // Spinner
        spinnerStatus = findViewById(R.id.spinnerStatus);

        // Buttons
        btnRefresh = findViewById(R.id.btnRefresh);
        btnApproveAll = findViewById(R.id.btnApproveAll);
        btnRejectAll = findViewById(R.id.btnRejectAll);
        btnExport = findViewById(R.id.btnExport);
        btnBack = findViewById(R.id.btnBack);
    }

    private void setupRoleBasedUI() {
        if (mode.equals("approval") || (userLevel.equals("admin") && !mode.equals("pelanggan"))) {
            // Admin mode - bisa lihat semua & approval
            tvTitle.setText("Data Semua Pengajuan Kredit");
            tvRoleInfo.setText("Mode: Admin - Semua Data");
            tvRoleInfo.setBackgroundColor(Color.parseColor("#E3F2FD"));
            findViewById(R.id.layoutApproval).setVisibility(View.VISIBLE);

        } else if (userLevel.equals("pelanggan") || mode.equals("pelanggan")) {
            // Pelanggan mode - hanya lihat data sendiri
            tvTitle.setText("Status Pengajuan Saya");
            tvRoleInfo.setText("Mode: Pelanggan - Data Pribadi");
            tvRoleInfo.setBackgroundColor(Color.parseColor("#E8F5E8"));
            findViewById(R.id.layoutApproval).setVisibility(View.GONE);
        }
    }

    private void setupSpinner() {
        ArrayAdapter<CharSequence> adapter;
        if (userLevel.equals("admin")) {
            adapter = ArrayAdapter.createFromResource(this,
                    R.array.status_filter_admin, android.R.layout.simple_spinner_item);
        } else {
            adapter = ArrayAdapter.createFromResource(this,
                    R.array.status_filter_pelanggan, android.R.layout.simple_spinner_item);
        }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerStatus.setAdapter(adapter);

        spinnerStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                filterByStatus(parent.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void setupButtonListeners() {
        btnSearch.setOnClickListener(v -> searchKredit());
        btnRefresh.setOnClickListener(v -> refreshData());
        btnApproveAll.setOnClickListener(v -> approveSelectedKredit());
        btnRejectAll.setOnClickListener(v -> rejectSelectedKredit());
        btnExport.setOnClickListener(v -> exportToPDF());
        btnBack.setOnClickListener(v -> onBackPressed());
    }

    private void loadDataKredit() {
        try {
            String result;
            if (userLevel.equals("admin") && !mode.equals("pelanggan")) {
                result = kredit.tampilKredit();
            } else {
                result = kredit.tampilKreditByKreditor(userKreditorId);
            }

            arrayKredit = new JSONArray(result);
            originalArrayKredit = new JSONArray(arrayKredit.toString());
            displayKreditData(arrayKredit);

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void displayKreditData(JSONArray dataArray) {
        tbQueryKredit.removeAllViews();
        buttonApproveList.clear();
        buttonRejectList.clear();
        selectedKreditMap.clear();

        // Create header row dengan style biru
        TableRow headerRow = new TableRow(this);
        headerRow.setBackgroundColor(Color.parseColor("#1976D2"));

        // Column configuration - SESUAIKAN DENGAN GAMBAR
        String[] headers;
        int[] minWidths;

        if (userLevel.equals("admin") && !mode.equals("pelanggan")) {
            headers = new String[]{"No", "Invoice", "Tanggal", "Kreditor", "Motor", "Harga", "DP", "Total", "Status", "Aksi"};
            minWidths = new int[]{
                    dpToPx(30),   // No
                    dpToPx(30),  // Invoice
                    dpToPx(110),  // Tanggal
                    dpToPx(100),  // Kreditor
                    dpToPx(100),  // Motor
                    dpToPx(120),  // Harga
                    dpToPx(100),  // DP
                    dpToPx(120),  // Total
                    dpToPx(100),  // Status
                    dpToPx(100)   // Aksi
            };
        } else {
            headers = new String[]{"No", "Invoice", "Tanggal", "Motor", "Harga", "DP", "Total", "Status"};
            minWidths = new int[]{
                    dpToPx(50),   // No
                    dpToPx(120),  // Invoice
                    dpToPx(110),  // Tanggal
                    dpToPx(250),  // Motor
                    dpToPx(120),  // Harga
                    dpToPx(100),  // DP
                    dpToPx(120),  // Total
                    dpToPx(100)   // Status
            };
        }

        for (int i = 0; i < headers.length; i++) {
            TextView headerView = createHeaderTextView(headers[i]);
            TableRow.LayoutParams params = new TableRow.LayoutParams(
                    minWidths[i],
                    TableRow.LayoutParams.WRAP_CONTENT
            );
            headerView.setLayoutParams(params);
            headerRow.addView(headerView);
        }

        tbQueryKredit.addView(headerRow);

        try {
            for (int i = 0; i < dataArray.length(); i++) {
                JSONObject jsonChildNode = dataArray.getJSONObject(i);
                String invoice = jsonChildNode.optString("invoice", "-");
                String tanggal = jsonChildNode.optString("tanggal", "-");
                String namaKreditor = jsonChildNode.optString("nama", "-");
                String namaMotor = jsonChildNode.optString("nmotor", "-");
                String harga = jsonChildNode.optString("hrgtunai", "0");
                String dp = jsonChildNode.optString("dp", "0");
                String total = jsonChildNode.optString("totalkredit", "0");
                String status = jsonChildNode.optString("status", "PENDING");

                // Format data sesuai gambar - TANPA PEMENDEKAN
                String displayTanggal = formatTanggal(tanggal);
                String displayHarga = "Rp " + formatNumber(harga);
                String displayDP = "Rp " + formatNumber(dp);
                String displayTotal = "Rp " + formatNumber(total);

                TableRow dataRow = new TableRow(this);
                dataRow.setBackgroundColor(i % 2 == 0 ? Color.parseColor("#FFFFFF") : Color.parseColor("#F5F5F5"));
                dataRow.setMinimumHeight(dpToPx(45));

                // No
                addDataCell(dataRow, String.valueOf(i + 1), minWidths[0], Gravity.CENTER);

                // Invoice
                addDataCell(dataRow, invoice, minWidths[1], Gravity.CENTER);

                // Tanggal
                addDataCell(dataRow, displayTanggal, minWidths[2], Gravity.CENTER);

                // Kreditor (admin only) - TAMPILKAN LENGKAP
                if (userLevel.equals("admin") && !mode.equals("pelanggan")) {
                    addDataCell(dataRow, namaKreditor, minWidths[3], Gravity.START);
                }

                // Motor - TAMPILKAN LENGKAP
                int motorIndex = userLevel.equals("admin") && !mode.equals("pelanggan") ? 4 : 3;
                addDataCell(dataRow, namaMotor, minWidths[motorIndex], Gravity.START);

                // Harga - TAMPILKAN SEPERTI DI GAMBAR
                int hargaIndex = userLevel.equals("admin") && !mode.equals("pelanggan") ? 5 : 4;
                addDataCell(dataRow, displayHarga, minWidths[hargaIndex], Gravity.END);

                // DP
                int dpIndex = userLevel.equals("admin") && !mode.equals("pelanggan") ? 6 : 5;
                addDataCell(dataRow, displayDP, minWidths[dpIndex], Gravity.END);

                // Total
                int totalIndex = userLevel.equals("admin") && !mode.equals("pelanggan") ? 7 : 6;
                addDataCell(dataRow, displayTotal, minWidths[totalIndex], Gravity.END);

                // Status
                int statusIndex = userLevel.equals("admin") && !mode.equals("pelanggan") ? 8 : 7;
                TextView statusView = createDataCell(getStatusDisplayText(status), minWidths[statusIndex], Gravity.CENTER);
                setStatusStyle(statusView, status);
                dataRow.addView(statusView);

                // Action buttons (admin only for pending status)
                if (userLevel.equals("admin") && !mode.equals("pelanggan") && status.equalsIgnoreCase("pending")) {
                    LinearLayout actionLayout = new LinearLayout(this);
                    actionLayout.setOrientation(LinearLayout.HORIZONTAL);
                    actionLayout.setGravity(Gravity.CENTER);

                    TableRow.LayoutParams actionParams = new TableRow.LayoutParams(
                            minWidths[9],
                            TableRow.LayoutParams.WRAP_CONTENT
                    );
                    actionLayout.setLayoutParams(actionParams);

                    Button btnApprove = createActionButton("✓", Color.parseColor("#4CAF50"));
                    btnApprove.setTag(invoice);
                    btnApprove.setOnClickListener(v -> approveSingleKredit(v.getTag().toString()));

                    Button btnReject = createActionButton("✗", Color.parseColor("#F44336"));
                    btnReject.setTag(invoice);
                    btnReject.setOnClickListener(v -> rejectSingleKredit(v.getTag().toString()));

                    actionLayout.addView(btnApprove);
                    actionLayout.addView(btnReject);
                    dataRow.addView(actionLayout);

                    buttonApproveList.add(btnApprove);
                    buttonRejectList.add(btnReject);
                } else if (userLevel.equals("admin") && !mode.equals("pelanggan")) {
                    addDataCell(dataRow, "-", minWidths[9], Gravity.CENTER);
                }

                tbQueryKredit.addView(dataRow);
            }

            // Empty state
            if (dataArray.length() == 0) {
                TableRow emptyRow = new TableRow(this);
                int spanCount = userLevel.equals("admin") && !mode.equals("pelanggan") ? 10 : 8;

                TextView emptyText = new TextView(this);
                emptyText.setText("Tidak ada data pengajuan kredit");
                emptyText.setTextColor(Color.GRAY);
                emptyText.setTypeface(Typeface.DEFAULT_BOLD);
                emptyText.setGravity(Gravity.CENTER);
                emptyText.setPadding(dpToPx(16), dpToPx(40), dpToPx(16), dpToPx(40));

                TableRow.LayoutParams params = new TableRow.LayoutParams(
                        TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.WRAP_CONTENT
                );
                params.span = spanCount;
                emptyText.setLayoutParams(params);
                emptyRow.addView(emptyText);
                tbQueryKredit.addView(emptyRow);
            }

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error menampilkan data", Toast.LENGTH_SHORT).show();
        }
    }

    // Helper methods
    private void addDataCell(TableRow row, String text, int minWidth, int gravity) {
        TextView textView = createDataCell(text, minWidth, gravity);
        row.addView(textView);
    }

    private TextView createDataCell(String text, int minWidth, int gravity) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(dpToPx(6), dpToPx(10), dpToPx(6), dpToPx(10));
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        textView.setGravity(gravity);
        textView.setSingleLine(true);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setTextColor(Color.parseColor("#333333"));
        textView.setTypeface(Typeface.DEFAULT);

        TableRow.LayoutParams params = new TableRow.LayoutParams(
                minWidth,
                TableRow.LayoutParams.WRAP_CONTENT
        );
        textView.setLayoutParams(params);

        return textView;
    }

    private TextView createHeaderTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextColor(Color.WHITE);
        textView.setPadding(dpToPx(6), dpToPx(12), dpToPx(6), dpToPx(12));
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setGravity(Gravity.CENTER);
        textView.setSingleLine(true);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setBackgroundColor(Color.parseColor("#1976D2"));
        return textView;
    }

    private Button createActionButton(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        button.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setAllCaps(false);

        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadius(dpToPx(4));
        shape.setColor(color);
        button.setBackground(shape);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                dpToPx(36),
                dpToPx(36)
        );
        params.setMargins(dpToPx(2), 0, dpToPx(2), 0);
        button.setLayoutParams(params);

        return button;
    }

    private void setStatusStyle(TextView statusView, String status) {
        GradientDrawable statusBackground = new GradientDrawable();
        statusBackground.setShape(GradientDrawable.RECTANGLE);
        statusBackground.setCornerRadius(dpToPx(4));
        statusBackground.setStroke(dpToPx(1), Color.parseColor("#E0E0E0"));

        switch (status.toLowerCase()) {
            case "approved":
                statusBackground.setColor(Color.parseColor("#E8F5E8"));
                statusView.setTextColor(Color.parseColor("#2E7D32"));
                statusView.setTypeface(Typeface.DEFAULT_BOLD);
                break;
            case "rejected":
                statusBackground.setColor(Color.parseColor("#FFEBEE"));
                statusView.setTextColor(Color.parseColor("#C62828"));
                statusView.setTypeface(Typeface.DEFAULT_BOLD);
                break;
            case "pending":
                statusBackground.setColor(Color.parseColor("#FFF3E0"));
                statusView.setTextColor(Color.parseColor("#EF6C00"));
                statusView.setTypeface(Typeface.DEFAULT_BOLD);
                break;
            default:
                statusBackground.setColor(Color.parseColor("#F5F5F5"));
                statusView.setTextColor(Color.parseColor("#666666"));
        }

        statusView.setBackground(statusBackground);
        statusView.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
    }

    private String getStatusDisplayText(String status) {
        switch (status.toLowerCase()) {
            case "approved": return "DISETUJUI";
            case "rejected": return "DITOLAK";
            case "pending": return "MENUNGGU";
            default: return status.toUpperCase();
        }
    }

    // Format tanggal dari "YYYY-MM-DD HH:MM:SS" menjadi "DD/MM/YYYY"
    private String formatTanggal(String tanggal) {
        if (tanggal == null || tanggal.length() < 10) {
            return tanggal;
        }
        try {
            String[] parts = tanggal.substring(0, 10).split("-");
            if (parts.length == 3) {
                return parts[2] + "/" + parts[1] + "/" + parts[0];
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tanggal;
    }

    // Format number tanpa pemendekan
    private String formatNumber(String number) {
        try {
            long value = Long.parseLong(number);
            return String.format("%,d", value).replace(',', '.');
        } catch (NumberFormatException e) {
            return number;
        }
    }

    private int dpToPx(int dp) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp,
                getResources().getDisplayMetrics()
        );
    }

    private void searchKredit() {
        String searchText = etSearch.getText().toString().trim().toLowerCase();

        if (TextUtils.isEmpty(searchText)) {
            displayKreditData(originalArrayKredit);
            return;
        }

        try {
            JSONArray filteredArray = new JSONArray();

            for (int i = 0; i < originalArrayKredit.length(); i++) {
                JSONObject kredit = originalArrayKredit.getJSONObject(i);
                String invoice = kredit.optString("invoice", "").toLowerCase();
                String namaKreditor = kredit.optString("nama", "").toLowerCase();
                String namaMotor = kredit.optString("nmotor", "").toLowerCase();

                if (invoice.contains(searchText) ||
                        namaKreditor.contains(searchText) ||
                        namaMotor.contains(searchText)) {
                    filteredArray.put(kredit);
                }
            }

            if (filteredArray.length() > 0) {
                arrayKredit = filteredArray;
                displayKreditData(filteredArray);
                Toast.makeText(this, "Ditemukan " + filteredArray.length() + " data", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Data tidak ditemukan", Toast.LENGTH_SHORT).show();
                displayKreditData(originalArrayKredit);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error searching data", Toast.LENGTH_SHORT).show();
        }
    }

    private void filterByStatus(String status) {
        if (status.equals("Semua Status")) {
            displayKreditData(originalArrayKredit);
            return;
        }

        try {
            JSONArray filteredArray = new JSONArray();

            for (int i = 0; i < originalArrayKredit.length(); i++) {
                JSONObject kredit = originalArrayKredit.getJSONObject(i);
                String kreditStatus = kredit.optString("status", "");

                if (kreditStatus.equalsIgnoreCase(status)) {
                    filteredArray.put(kredit);
                }
            }

            arrayKredit = filteredArray;
            displayKreditData(filteredArray);

            if (filteredArray.length() == 0) {
                Toast.makeText(this, "Tidak ada data dengan status " + status, Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void refreshData() {
        etSearch.setText("");
        spinnerStatus.setSelection(0);
        loadDataKredit();
        Toast.makeText(this, "Data diperbarui", Toast.LENGTH_SHORT).show();
    }

    private void approveSingleKredit(String invoice) {
        new AlertDialog.Builder(this)
                .setTitle("Konfirmasi Persetujuan")
                .setMessage("Setujui pengajuan kredit invoice " + invoice + "?")
                .setPositiveButton("Ya", (dialog, which) -> {
                    String result = kredit.approveKredit(invoice, session.getUsername());
                    Toast.makeText(DataPengajuanKreditActivity.this, result, Toast.LENGTH_SHORT).show();
                    refreshData();
                })
                .setNegativeButton("Tidak", null)
                .show();
    }

    private void rejectSingleKredit(String invoice) {
        new AlertDialog.Builder(this)
                .setTitle("Konfirmasi Penolakan")
                .setMessage("Tolak pengajuan kredit invoice " + invoice + "?")
                .setPositiveButton("Ya", (dialog, which) -> {
                    String result = kredit.rejectKredit(invoice, session.getUsername());
                    Toast.makeText(DataPengajuanKreditActivity.this, result, Toast.LENGTH_SHORT).show();
                    refreshData();
                })
                .setNegativeButton("Tidak", null)
                .show();
    }

    private void approveSelectedKredit() {
        Toast.makeText(this, "Fitur approve selected akan diimplementasikan", Toast.LENGTH_SHORT).show();
    }

    private void rejectSelectedKredit() {
        Toast.makeText(this, "Fitur reject selected akan diimplementasikan", Toast.LENGTH_SHORT).show();
    }

    private void exportToPDF() {
        Toast.makeText(this, "Fitur export PDF akan diimplementasikan", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}