package com.example.pr_kreditmotor;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class PengajuanKreditActivity extends AppCompatActivity {
    Kreditor kreditor = new Kreditor();
    Motor motor = new Motor();
    Kredit kredit = new Kredit();
    SessionManager session;

    // Views declaration dengan default values
    private Spinner SpinnerNamaKreditor = null;
    private Spinner SpinnerNamaMotor = null;
    private EditText editUangMuka = null;
    private EditText editBunga = null;
    private EditText editLamaAngsuran = null;
    private TextView textNamaMotor = null;
    private TextView textAlamatKreditor = null;
    private TextView textNamaKreditor = null;
    private TextView textHargaMotor = null;
    private TextView textHargaKredit = null;
    private TextView textTotalKredit = null;
    private TextView textAngsuranPerbulan = null;
    private TextView tvRoleInfo = null;
    private TextView tvKreditorLabel = null;
    private Button buttonProcessPengajuanKredit = null;
    private Button buttonSimpanPengajuanKredit = null;
    private Button buttonResetKredit = null;

    ArrayList<String> arrayListNamaKreditor = new ArrayList<>();
    ArrayList<String> arrayListNamaMotor = new ArrayList<>();
    JSONArray arrayKreditor;
    JSONArray arrayMotor;

    private String userLevel = "pelanggan"; // default value
    private String userKreditorId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pengajuan_kredit);

        // Initialize session dengan try-catch
        try {
            session = new SessionManager(this);
            userLevel = session.getUserLevel();
            userKreditorId = session.getIdKreditor();
        } catch (Exception e) {
            Log.e("PengajuanKredit", "Session init error: " + e.getMessage());
        }

        // Handle null values
        if (userLevel == null) userLevel = "pelanggan";
        if (userKreditorId == null) userKreditorId = "";

        // Initialize semua views dengan safety check
        initializeViewsWithProtection();

        // Setup UI dengan protection
        setupRoleBasedUISafe();
        setupSpinnerListenersSafe();
        setupButtonListenersSafe();

        // Load data based on role
        if (userLevel.equals("pelanggan")) {
            loadPelangganData();
        } else {
            SpinerKreditor();
        }
        SpinerMotor();

        // Set initial state for simpan button
        if (buttonSimpanPengajuanKredit != null) {
            buttonSimpanPengajuanKredit.setEnabled(false);
        }
    }

    /**
     * METHOD INISIALISASI YANG AMAN - dengan try-catch untuk setiap view
     */
    private void initializeViewsWithProtection() {
        try {
            // TextViews - dengan individual try-catch
            textNamaKreditor = safeFindViewById(R.id.TextNamaKreditor, "TextNamaKreditor");
            textAlamatKreditor = safeFindViewById(R.id.TextAlamatKreditor, "TextAlamatKreditor");
            textNamaMotor = safeFindViewById(R.id.textNamaMotor, "textNamaMotor");
            textHargaMotor = safeFindViewById(R.id.textHargaMotor, "textHargaMotor");
            textHargaKredit = safeFindViewById(R.id.textHargaKredit, "textHargaKredit");
            textTotalKredit = safeFindViewById(R.id.textTotalKredit, "textTotalKredit");
            textAngsuranPerbulan = safeFindViewById(R.id.textAngsuranPerbulan, "textAngsuranPerbulan");
            tvRoleInfo = safeFindViewById(R.id.tvRoleInfo, "tvRoleInfo");
            tvKreditorLabel = safeFindViewById(R.id.TextView01, "TextView01");

            // EditTexts
            editBunga = safeFindViewById(R.id.editBunga, "editBunga");
            editUangMuka = safeFindViewById(R.id.editUangMuka, "editUangMuka");
            editLamaAngsuran = safeFindViewById(R.id.editLamaAngsuran, "editLamaAngsuran");

            // Buttons
            buttonProcessPengajuanKredit = safeFindViewById(R.id.buttonProcessPengajuanKredit, "buttonProcessPengajuanKredit");
            buttonSimpanPengajuanKredit = safeFindViewById(R.id.buttonSimpanPengajuanKredit, "buttonSimpanPengajuanKredit");
            buttonResetKredit = safeFindViewById(R.id.buttonResetKredit, "buttonResetKredit");

            // Spinners
            SpinnerNamaKreditor = safeFindViewById(R.id.SpinnerNamaKreditor, "SpinnerNamaKreditor");
            SpinnerNamaMotor = safeFindViewById(R.id.SpinnerNamaMotor, "SpinnerNamaMotor");

        } catch (Exception e) {
            Log.e("PengajuanKredit", "Critical error in view initialization: " + e.getMessage());
            Toast.makeText(this, "Error inisialisasi layout", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Helper method untuk findViewById yang aman
     */
    private <T extends View> T safeFindViewById(int id, String viewName) {
        try {
            T view = findViewById(id);
            if (view == null) {
                Log.w("PengajuanKredit", "View not found: " + viewName + " (ID: " + id + ")");
            }
            return view;
        } catch (Exception e) {
            Log.e("PengajuanKredit", "Error finding view: " + viewName + " - " + e.getMessage());
            return null;
        }
    }

    /**
     * SETUP ROLE BASED UI YANG AMAN - tidak akan pernah crash
     */
    private void setupRoleBasedUISafe() {
        try {
            if (userLevel.equals("pelanggan")) {
                // Setup untuk pelanggan
                if (tvRoleInfo != null) {
                    tvRoleInfo.setText("Mode: Pelanggan - Pengajuan untuk diri sendiri");
                    tvRoleInfo.setBackgroundColor(Color.parseColor("#C8E6C9"));
                }

                // Sembunyikan spinner kreditor untuk pelanggan
                if (SpinnerNamaKreditor != null) {
                    SpinnerNamaKreditor.setVisibility(View.GONE);
                } else {
                    Log.w("PengajuanKredit", "SpinnerNamaKreditor is null - cannot hide");
                }

                if (tvKreditorLabel != null) {
                    tvKreditorLabel.setVisibility(View.GONE);
                }

            } else {
                // Setup untuk admin
                if (tvRoleInfo != null) {
                    tvRoleInfo.setText("Mode: Admin - Pengajuan untuk kreditor");
                    tvRoleInfo.setBackgroundColor(Color.parseColor("#BBDEFB"));
                }

                // Tampilkan spinner kreditor untuk admin
                if (SpinnerNamaKreditor != null) {
                    SpinnerNamaKreditor.setVisibility(View.VISIBLE);
                } else {
                    Log.w("PengajuanKredit", "SpinnerNamaKreditor is null - cannot show");
                    if (tvRoleInfo != null) {
                        tvRoleInfo.setText(tvRoleInfo.getText() + " (Fitur terbatas)");
                    }
                }

                if (tvKreditorLabel != null) {
                    tvKreditorLabel.setVisibility(View.VISIBLE);
                }
            }
        } catch (Exception e) {
            Log.e("PengajuanKredit", "Error in setupRoleBasedUI: " + e.getMessage());
        }
    }

    /**
     * SETUP SPINNER LISTENERS YANG AMAN
     */
    private void setupSpinnerListenersSafe() {
        // Spinner Kreditor - hanya untuk admin
        if (SpinnerNamaKreditor != null && userLevel.equals("admin")) {
            SpinnerNamaKreditor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    getNamaKreditor();
                }

                @Override
                public void onNothingSelected(AdapterView<?> arg0) {
                }
            });
        }

        // Spinner Motor - untuk semua user
        if (SpinnerNamaMotor != null) {
            SpinnerNamaMotor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    getKdmotorKredit();
                }

                @Override
                public void onNothingSelected(AdapterView<?> arg0) {
                }
            });
        }
    }

    /**
     * SETUP BUTTON LISTENERS YANG AMAN
     */
    private void setupButtonListenersSafe() {
        // Button Process
        if (buttonProcessPengajuanKredit != null) {
            buttonProcessPengajuanKredit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    HitungKredit();
                }
            });
        } else {
            Log.w("PengajuanKredit", "buttonProcessPengajuanKredit is null");
        }

        // Button Reset
        if (buttonResetKredit != null) {
            buttonResetKredit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    resetFormSafe();
                }
            });
        }

        // Button Simpan
        if (buttonSimpanPengajuanKredit != null) {
            buttonSimpanPengajuanKredit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    simpanKredit();
                }
            });
        }
    }

    /**
     * RESET FORM YANG AMAN
     */
    private void resetFormSafe() {
        try {
            if (editUangMuka != null) editUangMuka.setText("");
            if (editBunga != null) editBunga.setText("");
            if (editLamaAngsuran != null) editLamaAngsuran.setText("");
            if (textHargaKredit != null) textHargaKredit.setText("0");
            if (textTotalKredit != null) textTotalKredit.setText("0");
            if (textAngsuranPerbulan != null) textAngsuranPerbulan.setText("0");
            if (buttonSimpanPengajuanKredit != null) buttonSimpanPengajuanKredit.setEnabled(false);
        } catch (Exception e) {
            Log.e("PengajuanKredit", "Error in resetForm: " + e.getMessage());
        }
    }

    private void loadPelangganData() {
        if (userKreditorId == null || userKreditorId.isEmpty() || userKreditorId.equals("0")) {
            Log.w("PengajuanKredit", "Invalid userKreditorId for pelanggan");
            return;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String result = kreditor.select_by_Idkreditor(userKreditorId);
                    Log.d("PengajuanKredit", "Response Kreditor: " + result);

                    String namaEdit = "";
                    String alamatEdit = "";

                    if (result != null && !result.isEmpty()) {
                        JSONObject jsonResponse = new JSONObject(result);
                        if (jsonResponse.getBoolean("success")) {
                            JSONArray dataArray = jsonResponse.getJSONArray("data");
                            if (dataArray.length() > 0) {
                                JSONObject data = dataArray.getJSONObject(0);
                                namaEdit = data.optString("nama", "");
                                alamatEdit = data.optString("alamat", "");
                            }
                        }
                    }

                    final String finalNamaEdit = namaEdit;
                    final String finalAlamatEdit = alamatEdit;

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (textNamaKreditor != null) textNamaKreditor.setText(finalNamaEdit);
                            if (textAlamatKreditor != null) textAlamatKreditor.setText(finalAlamatEdit);
                        }
                    });
                } catch (Exception e) {
                    Log.e("PengajuanKredit", "Error in loadPelangganData: " + e.getMessage());
                }
            }
        }).start();
    }

    public void SpinerKreditor() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String result = kreditor.tampilKreditorbyIdNama();
                    Log.d("PengajuanKredit", "Response Kreditor List: " + result);

                    if (result != null && !result.isEmpty()) {
                        if (result.startsWith("[")) {
                            arrayKreditor = new JSONArray(result);
                        } else {
                            JSONObject jsonResponse = new JSONObject(result);
                            if (jsonResponse.getBoolean("success")) {
                                arrayKreditor = jsonResponse.getJSONArray("data");
                            }
                        }

                        arrayListNamaKreditor.clear();
                        for (int i = 0; i < arrayKreditor.length(); i++) {
                            JSONObject jsonChildNode = arrayKreditor.getJSONObject(i);
                            String idkreditor = jsonChildNode.optString("idkreditor");
                            String nama = jsonChildNode.optString("nama");
                            arrayListNamaKreditor.add(idkreditor + " - " + nama);
                        }

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (SpinnerNamaKreditor != null) {
                                    ArrayAdapter<String> adapter = new ArrayAdapter<>(
                                            PengajuanKreditActivity.this,
                                            android.R.layout.simple_spinner_item,
                                            arrayListNamaKreditor
                                    );
                                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                    SpinnerNamaKreditor.setAdapter(adapter);
                                    if (arrayListNamaKreditor.size() > 0) {
                                        SpinnerNamaKreditor.setSelection(0);
                                    }
                                }
                            }
                        });
                    }
                } catch (Exception e) {
                    Log.e("PengajuanKredit", "Error in SpinerKreditor: " + e.getMessage());
                }
            }
        }).start();
    }

    public void SpinerMotor() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String result = motor.tampilMotorbyIdNama();
                    Log.d("PengajuanKredit", "Response Motor List: " + result);

                    if (result != null && !result.isEmpty()) {
                        if (result.trim().startsWith("[")) {
                            arrayMotor = new JSONArray(result);
                        } else {
                            JSONObject jsonResponse = new JSONObject(result);
                            if (jsonResponse.getBoolean("success")) {
                                arrayMotor = jsonResponse.getJSONArray("data");
                            } else {
                                arrayMotor = new JSONArray();
                            }
                        }

                        arrayListNamaMotor.clear();
                        for (int i = 0; i < arrayMotor.length(); i++) {
                            JSONObject jsonChildNode = arrayMotor.getJSONObject(i);
                            String kdmotor = jsonChildNode.optString("kdmotor");
                            String nama = jsonChildNode.optString("nama");
                            arrayListNamaMotor.add(kdmotor + " - " + nama);
                        }

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (SpinnerNamaMotor != null) {
                                    ArrayAdapter<String> adapter = new ArrayAdapter<>(
                                            PengajuanKreditActivity.this,
                                            android.R.layout.simple_spinner_item,
                                            arrayListNamaMotor
                                    );
                                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                    SpinnerNamaMotor.setAdapter(adapter);
                                    if (arrayListNamaMotor.size() > 0) {
                                        SpinnerNamaMotor.setSelection(0);
                                    }
                                }
                            }
                        });
                    }
                } catch (Exception e) {
                    Log.e("PengajuanKredit", "Error in SpinerMotor: " + e.getMessage());
                }
            }
        }).start();
    }

    public void getNamaKreditor() {
        if (SpinnerNamaKreditor == null || SpinnerNamaKreditor.getSelectedItem() == null) return;

        String selectedItem = SpinnerNamaKreditor.getSelectedItem().toString();
        String[] parts = selectedItem.split(" - ");
        if (parts.length < 2) return;

        final String idkreditor = parts[0];

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String result = kreditor.select_by_Idkreditor(idkreditor);
                    Log.d("PengajuanKredit", "Response Kreditor Detail: " + result);

                    String namaEdit = "";
                    String alamatEdit = "";

                    if (result != null && !result.isEmpty()) {
                        JSONObject jsonResponse = new JSONObject(result);
                        if (jsonResponse.getBoolean("success")) {
                            JSONArray dataArray = jsonResponse.getJSONArray("data");
                            if (dataArray.length() > 0) {
                                JSONObject data = dataArray.getJSONObject(0);
                                namaEdit = data.optString("nama", "");
                                alamatEdit = data.optString("alamat", "");
                            }
                        }
                    }

                    final String finalNamaEdit = namaEdit;
                    final String finalAlamatEdit = alamatEdit;

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (textNamaKreditor != null) textNamaKreditor.setText(finalNamaEdit);
                            if (textAlamatKreditor != null) textAlamatKreditor.setText(finalAlamatEdit);
                        }
                    });
                } catch (Exception e) {
                    Log.e("PengajuanKredit", "Error in getNamaKreditor: " + e.getMessage());
                }
            }
        }).start();
    }

    public void getKdmotorKredit() {
        if (SpinnerNamaMotor == null || SpinnerNamaMotor.getSelectedItem() == null) return;

        String selectedItem = SpinnerNamaMotor.getSelectedItem().toString();
        String[] parts = selectedItem.split(" - ");
        if (parts.length < 2) return;

        final String kdmotor = parts[0];

        new Thread(new Runnable() {
            @Override
            public void run() {
                String namaEdit = "";
                String hargaEdit = "0";

                try {
                    String result = motor.select_by_KdmotorKredit(kdmotor);
                    Log.d("PengajuanKredit", "Response Motor Detail: " + result);

                    if (result != null && !result.isEmpty()) {
                        if (result.trim().startsWith("[")) {
                            JSONArray dataArray = new JSONArray(result);
                            if (dataArray.length() > 0) {
                                JSONObject data = dataArray.getJSONObject(0);
                                namaEdit = data.optString("nama", "");
                                hargaEdit = data.optString("harga", "0");
                                Log.d("PengajuanKredit", "Parsed data - Nama: " + namaEdit + ", Harga: " + hargaEdit);
                            } else {
                                Log.w("PengajuanKredit", "Empty data array");
                            }
                        } else {
                            try {
                                JSONObject jsonResponse = new JSONObject(result);
                                if (jsonResponse.has("success") && jsonResponse.getBoolean("success")) {
                                    JSONArray dataArray = jsonResponse.getJSONArray("data");
                                    if (dataArray.length() > 0) {
                                        JSONObject data = dataArray.getJSONObject(0);
                                        namaEdit = data.optString("nama", "");
                                        hargaEdit = data.optString("harga", "0");
                                    }
                                }
                            } catch (JSONException e) {
                                Log.e("PengajuanKredit", "Failed to parse as JSONObject");
                            }
                        }
                    } else {
                        Log.w("PengajuanKredit", "Empty response from server");
                    }
                } catch (Exception e) {
                    Log.e("PengajuanKredit", "Error in getKdmotorKredit: " + e.getMessage());
                }

                final String finalNamaEdit = namaEdit;
                final String finalHargaEdit = hargaEdit;

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (textNamaMotor != null) textNamaMotor.setText(finalNamaEdit);
                        if (textHargaMotor != null) textHargaMotor.setText(finalHargaEdit);
                    }
                });
            }
        }).start();
    }

    public void HitungKredit() {
        if (textHargaMotor == null || editUangMuka == null || editBunga == null || editLamaAngsuran == null) {
            Toast.makeText(this, "Error: Form tidak lengkap", Toast.LENGTH_LONG).show();
            return;
        }

        String sharga = textHargaMotor.getText().toString();
        String sdp = editUangMuka.getText().toString();
        String sbunga = editBunga.getText().toString();
        String slama = editLamaAngsuran.getText().toString();

        if (sharga.equals("") || sharga.equals("0") ||
                sdp.equals("") || sdp.equals("0") ||
                sbunga.equals("") || sbunga.equals("0") ||
                slama.equals("") || slama.equals("0")) {
            Toast.makeText(this, "Silahkan Lengkapi Data !", Toast.LENGTH_LONG).show();
        } else {
            try {
                double harga = Double.parseDouble(sharga);
                double dp = Double.parseDouble(sdp);
                double bunga = Double.parseDouble(sbunga);
                double lama = Double.parseDouble(slama);

                if (dp >= harga) {
                    Toast.makeText(this, "Uang muka tidak boleh lebih dari harga motor!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (lama <= 0) {
                    Toast.makeText(this, "Lama angsuran harus lebih dari 0!", Toast.LENGTH_SHORT).show();
                    return;
                }

                double HargaKredit = harga - dp;
                double TotalKredit = HargaKredit + (HargaKredit * (bunga / 100) * (lama / 12));
                double Angsuran = TotalKredit / lama;

                String shargaKredit = String.format("%,.2f", HargaKredit);
                if (textHargaKredit != null) textHargaKredit.setText(shargaKredit);

                String sTotalKredit = String.format("%,.2f", TotalKredit);
                if (textTotalKredit != null) textTotalKredit.setText(sTotalKredit);

                String sAngsuran = String.format("%,.2f", Angsuran);
                if (textAngsuranPerbulan != null) textAngsuranPerbulan.setText(sAngsuran);

                if (buttonSimpanPengajuanKredit != null) {
                    buttonSimpanPengajuanKredit.setEnabled(true);
                }

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Format angka tidak valid!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void simpanKredit() {
        if (userLevel.equals("pelanggan") && (userKreditorId == null || userKreditorId.isEmpty() || userKreditorId.equals("0"))) {
            Toast.makeText(this, "Error: Data pelanggan tidak valid!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (SpinnerNamaMotor == null || SpinnerNamaMotor.getSelectedItem() == null) {
            Toast.makeText(this, "Pilih motor terlebih dahulu!", Toast.LENGTH_SHORT).show();
            return;
        }

        String idkreditor;
        if (userLevel.equals("pelanggan")) {
            idkreditor = userKreditorId;
        } else {
            if (SpinnerNamaKreditor == null || SpinnerNamaKreditor.getSelectedItem() == null) {
                Toast.makeText(this, "Pilih kreditor terlebih dahulu!", Toast.LENGTH_SHORT).show();
                return;
            }
            String selectedKreditor = SpinnerNamaKreditor.getSelectedItem().toString();
            String[] parts = selectedKreditor.split(" - ");
            if (parts.length < 2) {
                Toast.makeText(this, "Format data kreditor tidak valid!", Toast.LENGTH_SHORT).show();
                return;
            }
            idkreditor = parts[0];
        }

        String selectedMotor = SpinnerNamaMotor.getSelectedItem().toString();
        String[] motorParts = selectedMotor.split(" - ");
        if (motorParts.length < 2) {
            Toast.makeText(this, "Format data motor tidak valid!", Toast.LENGTH_SHORT).show();
            return;
        }
        String kdmotor = motorParts[0];

        if (textHargaMotor == null || textHargaKredit == null || textTotalKredit == null || textAngsuranPerbulan == null) {
            Toast.makeText(this, "Error: Data kredit tidak lengkap", Toast.LENGTH_SHORT).show();
            return;
        }

        String hrgtunai = textHargaMotor.getText().toString();
        String dp = editUangMuka != null ? editUangMuka.getText().toString() : "0";
        String hrgkredit = textHargaKredit.getText().toString().replace(",", "");
        String bunga = editBunga != null ? editBunga.getText().toString() : "0";
        String lama = editLamaAngsuran != null ? editLamaAngsuran.getText().toString() : "0";
        String totalkredit = textTotalKredit.getText().toString().replace(",", "");
        String angsuran = textAngsuranPerbulan.getText().toString().replace(",", "");

        if (hrgkredit.equals("0") || totalkredit.equals("0") || angsuran.equals("0")) {
            Toast.makeText(this, "Hitung kredit terlebih dahulu!", Toast.LENGTH_SHORT).show();
            return;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final String laporan = kredit.simpan_kredit(idkreditor, kdmotor, hrgtunai, dp, hrgkredit, bunga, lama, totalkredit, angsuran);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(PengajuanKreditActivity.this, laporan, Toast.LENGTH_SHORT).show();

                            if (laporan.contains("Berhasil") || laporan.contains("sukses") || laporan.contains("success")) {
                                resetFormSafe();
                                if (userLevel.equals("pelanggan")) {
                                    finish();
                                }
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e("PengajuanKredit", "Error in simpanKredit: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(PengajuanKreditActivity.this, "Error menyimpan data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }).start();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}