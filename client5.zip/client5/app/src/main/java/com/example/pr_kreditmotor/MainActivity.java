package com.example.pr_kreditmotor;

// =============================================
// IMPORT YANG DIPERLUKAN
// =============================================
import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.TabHost;

@SuppressWarnings("deprecation")
public class MainActivity extends TabActivity {

    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize SessionManager
        session = new SessionManager(this);

        // Check login status - redirect to LoginActivity if not logged in
        if (!session.isLoggedIn()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_main);

        Resources res = getResources();
        TabHost tabHost = getTabHost();
        TabHost.TabSpec spec;
        Intent intent;

        // --- Tab 1: Home ---
        intent = new Intent().setClass(this, HomeActivity.class);
        spec = tabHost.newTabSpec("Home")
                .setIndicator("Home")
                .setContent(intent);
        tabHost.addTab(spec);

        // --- Tab 2: Transaksi ---
        intent = new Intent().setClass(this, TransaksiActivity.class);
        spec = tabHost.newTabSpec("Transaksi")
                .setIndicator("Transaksi")
                .setContent(intent);
        tabHost.addTab(spec);

        // --- Tab 3: About ---
        intent = new Intent().setClass(this, AboutActivity.class);
        spec = tabHost.newTabSpec("About")
                .setIndicator("About")
                .setContent(intent);
        tabHost.addTab(spec);

        // Tab pertama yang ditampilkan
        tabHost.setCurrentTab(0);
    }
}