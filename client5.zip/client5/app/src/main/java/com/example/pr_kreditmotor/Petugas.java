package com.example.pr_kreditmotor;

public class Petugas extends Koneksi {
    private long id;
    Server server = new Server();
    String SERVER = server.urlDatabase1();
    String URL = "http://" + SERVER + "/jskreditmotor/tbpetugas.php";
    String url = "";
    String response = "";

    public String tampilPetugas() {
        try {
            url = URL + "?operasi=view";
            System.out.println("URL Tampil Petugas: " + url);
            response = call(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    public String insertPetugas(String kdpetugas, String nama, String jabatan) {
        try {
            nama = nama.replace(" ", "%20");
            jabatan = jabatan.replace(" ", "%20");
            url = URL + "?operasi=insert&kdpetugas=" + kdpetugas + "&nama=" + nama + "&jabatan=" + jabatan;
            System.out.println("URL Insert Petugas : " + url);
            response = call(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    public String getPetugasByKdpetugas(int idpetugas) {
        try {
            url = URL + "?operasi=get_petugas_by_kdpetugas&idpetugas=" + idpetugas;
            System.out.println("URL Get Petugas: " + url);
            response = call(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    public String updatePetugas(String idpetugas, String kdpetugas, String nama, String jabatan) {
        try {
            nama = nama.replace(" ", "%20");
            jabatan = jabatan.replace(" ", "%20");
            url = URL + "?operasi=update&idpetugas=" + idpetugas + "&kdpetugas=" + kdpetugas + "&nama=" + nama + "&jabatan=" + jabatan;
            System.out.println("URL Update Petugas : " + url);
            response = call(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    public String deletePetugas(int idpetugas) {
        try {
            url = URL + "?operasi=delete&idpetugas=" + idpetugas;
            System.out.println("URL Hapus Petugas : " + url);
            response = call(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    // Method baru untuk profil
    public String select_by_username(String username) {
        try {
            url = URL + "?operasi=get_petugas_by_username&username=" + username;
            System.out.println("URL Get Petugas by Username: " + url);
            response = call(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    public String update_petugas_profil(String username, String nama, String email) {
        try {
            nama = nama.replace(" ", "%20");
            email = email != null ? email.replace(" ", "%20") : "";
            url = URL + "?operasi=update_profil&username=" + username + "&nama=" + nama + "&email=" + email;
            System.out.println("URL Update Profil Petugas : " + url);
            response = call(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    public String update_password(String username, String password) {
        try {
            url = URL + "?operasi=update_password&username=" + username + "&password=" + password;
            System.out.println("URL Update Password Petugas : " + url);
            response = call(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    public long getId() {
        return id;
    }
}