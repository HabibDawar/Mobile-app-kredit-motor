package com.example.pr_kreditmotor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class DataKreditorActivity extends AppCompatActivity implements View.OnClickListener {

    Kreditor kreditor = new Kreditor();
    TableLayout tbKreditor;
    HorizontalScrollView horizontalScrollView;
    Button btTambahKreditor, btRefreshDataKreditor, btSortNama, btSortPekerjaan, btSearch;
    EditText etSearch;
    ArrayList<Button> buttonEdit = new ArrayList<Button>();
    ArrayList<Button> buttonDelete = new ArrayList<Button>();
    JSONArray arrayKreditor;
    JSONArray originalArrayKreditor;
    SessionManager session;

    // Sorting state
    private boolean sortNamaAscending = true;
    private boolean sortPekerjaanAscending = true;

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_kreditor);

        session = new SessionManager(this);

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        initViews();
        setupButtonListeners();
        setupRoleBasedUI();
        tampilDataKreditor();
    }

    private void initViews() {
        tbKreditor = findViewById(R.id.tbKreditor);
        horizontalScrollView = findViewById(R.id.horizontalScrollView);
        btTambahKreditor = findViewById(R.id.btTambahKreditor);
        btRefreshDataKreditor = findViewById(R.id.btRefreshDataKreditor);
        btSortNama = findViewById(R.id.btSortNama);
        btSortPekerjaan = findViewById(R.id.btSortPekerjaan);
        btSearch = findViewById(R.id.btSearch);
        etSearch = findViewById(R.id.etSearch);
    }

    private void setupButtonListeners() {
        btSortNama.setOnClickListener(v -> sortByNama());
        btSortPekerjaan.setOnClickListener(v -> sortByPekerjaan());
        btSearch.setOnClickListener(v -> searchKreditor());
        btRefreshDataKreditor.setOnClickListener(v -> {
            etSearch.setText("");
            tampilDataKreditor();
        });
        btTambahKreditor.setOnClickListener(v -> tambahKreditor());
    }

    private void setupRoleBasedUI() {
        TextView tvTitle = findViewById(R.id.tvTitle);
        TextView tvRoleInfo = findViewById(R.id.tvRoleInfo);

        if (session.getUserLevel().equals("admin")) {
            tvTitle.setText("Data Semua Kreditor");
            tvRoleInfo.setText("Mode: Admin - Semua Data");
            tvRoleInfo.setBackgroundColor(Color.parseColor("#E3F2FD"));
        } else {
            tvTitle.setText("Data Kreditor");
            tvRoleInfo.setText("Mode: Pelanggan - View Only");
            tvRoleInfo.setBackgroundColor(Color.parseColor("#E8F5E8"));
            btTambahKreditor.setVisibility(View.GONE);
            btSortNama.setVisibility(View.GONE);
            btSortPekerjaan.setVisibility(View.GONE);
        }
    }

    public void tampilDataKreditor() {
        try {
            String response = kreditor.tampilKreditor();
            Log.d("DataKreditor", "Raw Response: " + response);

            JSONObject jsonResponse = new JSONObject(response);

            if (jsonResponse.getBoolean("success")) {
                arrayKreditor = jsonResponse.getJSONArray("data");
                originalArrayKreditor = new JSONArray(arrayKreditor.toString());
                displayKreditorData(arrayKreditor);
                Toast.makeText(this, "Data berhasil dimuat", Toast.LENGTH_SHORT).show();
            } else {
                String message = jsonResponse.getString("message");
                Toast.makeText(this, "Gagal memuat data: " + message, Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {
            e.printStackTrace();
            Log.e("DataKreditor", "Error parsing JSON: " + e.getMessage());
            Toast.makeText(this, "Error parsing data", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayKreditorData(JSONArray dataArray) {
        tbKreditor.removeAllViews();
        buttonEdit.clear();
        buttonDelete.clear();

        // Create header row dengan style biru
        TableRow headerRow = new TableRow(this);
        headerRow.setBackgroundColor(Color.parseColor("#1976D2"));

        // Column configuration - SESUAIKAN LEBAR KOLOM
        String[] headers;
        int[] minWidths;

        if (session.getUserLevel().equals("admin")) {
            headers = new String[]{"No", "ID", "Nama", "Pekerjaan", "Telepon", "Alamat", "Aksi"};
            minWidths = new int[]{
                    dpToPx(30),   // No
                    dpToPx(30),   // ID
                    dpToPx(120),  // Nama
                    dpToPx(100),  // Pekerjaan
                    dpToPx(100),  // Telepon
                    dpToPx(100),  // Alamat
                    dpToPx(120)   // Aksi
            };
        } else {
            headers = new String[]{"No", "ID", "Nama", "Pekerjaan", "Telepon", "Alamat"};
            minWidths = new int[]{
                    dpToPx(30),   // No
                    dpToPx(30),   // ID
                    dpToPx(120),  // Nama
                    dpToPx(100),  // Pekerjaan
                    dpToPx(100),  // Telepon
                    dpToPx(000)   // Alamat
            };
        }

        for (int i = 0; i < headers.length; i++) {
            TextView headerView = createHeaderTextView(headers[i]);
            TableRow.LayoutParams params = new TableRow.LayoutParams(
                    minWidths[i],
                    TableRow.LayoutParams.WRAP_CONTENT
            );
            headerView.setLayoutParams(params);
            headerRow.addView(headerView);
        }

        tbKreditor.addView(headerRow);

        try {
            for (int i = 0; i < dataArray.length(); i++) {
                JSONObject jsonChildNode = dataArray.getJSONObject(i);
                String idkreditor = jsonChildNode.optString("idkreditor", "-");
                String nama = jsonChildNode.optString("nama", "-");
                String pekerjaan = jsonChildNode.optString("pekerjaan", "-");
                String telp = jsonChildNode.optString("telp", "-");
                String alamat = jsonChildNode.optString("alamat", "-");

                TableRow dataRow = new TableRow(this);
                dataRow.setBackgroundColor(i % 2 == 0 ? Color.parseColor("#FFFFFF") : Color.parseColor("#F5F5F5"));
                dataRow.setMinimumHeight(dpToPx(45));

                // No
                addDataCell(dataRow, String.valueOf(i + 1), minWidths[0], Gravity.CENTER);

                // ID
                addDataCell(dataRow, idkreditor, minWidths[1], Gravity.CENTER);

                // Nama
                addDataCell(dataRow, nama, minWidths[2], Gravity.START);

                // Pekerjaan
                addDataCell(dataRow, pekerjaan, minWidths[3], Gravity.START);

                // Telepon
                addDataCell(dataRow, telp, minWidths[4], Gravity.CENTER);

                // Alamat
                addDataCell(dataRow, alamat, minWidths[5], Gravity.START);

                // Action buttons (admin only)
                if (session.getUserLevel().equals("admin")) {
                    LinearLayout actionLayout = new LinearLayout(this);
                    actionLayout.setOrientation(LinearLayout.HORIZONTAL);
                    actionLayout.setGravity(Gravity.CENTER);

                    TableRow.LayoutParams actionParams = new TableRow.LayoutParams(
                            minWidths[6],
                            TableRow.LayoutParams.WRAP_CONTENT
                    );
                    actionLayout.setLayoutParams(actionParams);

                    Button btnEdit = createActionButton("✎", Color.parseColor("#2196F3"));
                    btnEdit.setTag("Edit");
                    btnEdit.setId(Integer.parseInt(idkreditor));
                    btnEdit.setOnClickListener(this);

                    Button btnDelete = createActionButton("✕", Color.parseColor("#F44336"));
                    btnDelete.setTag("Delete");
                    btnDelete.setId(Integer.parseInt(idkreditor));
                    btnDelete.setOnClickListener(this);

                    actionLayout.addView(btnEdit);
                    actionLayout.addView(btnDelete);
                    dataRow.addView(actionLayout);

                    buttonEdit.add(btnEdit);
                    buttonDelete.add(btnDelete);
                }

                tbKreditor.addView(dataRow);
            }

            // Empty state
            if (dataArray.length() == 0) {
                TableRow emptyRow = new TableRow(this);
                int spanCount = session.getUserLevel().equals("admin") ? 7 : 6;

                TextView emptyText = new TextView(this);
                emptyText.setText("Tidak ada data kreditor");
                emptyText.setTextColor(Color.GRAY);
                emptyText.setTypeface(Typeface.DEFAULT_BOLD);
                emptyText.setGravity(Gravity.CENTER);
                emptyText.setPadding(dpToPx(16), dpToPx(40), dpToPx(16), dpToPx(40));

                TableRow.LayoutParams params = new TableRow.LayoutParams(
                        TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.WRAP_CONTENT
                );
                params.span = spanCount;
                emptyText.setLayoutParams(params);
                emptyRow.addView(emptyText);
                tbKreditor.addView(emptyRow);
            }

        } catch (JSONException e) {
            e.printStackTrace();
            Log.e("DataKreditor", "Error displaying data: " + e.getMessage());

            TableRow errorRow = new TableRow(this);
            TextView errorText = new TextView(this);
            errorText.setText("Error menampilkan data: " + e.getMessage());
            errorText.setPadding(dpToPx(16), dpToPx(20), dpToPx(16), dpToPx(20));
            errorText.setTextColor(Color.RED);
            errorRow.addView(errorText);
            tbKreditor.addView(errorRow);
        }
    }

    // Helper methods untuk tabel
    private void addDataCell(TableRow row, String text, int minWidth, int gravity) {
        TextView textView = createDataCell(text, minWidth, gravity);
        row.addView(textView);
    }

    private TextView createDataCell(String text, int minWidth, int gravity) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(dpToPx(6), dpToPx(10), dpToPx(6), dpToPx(10));
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        textView.setGravity(gravity);
        textView.setSingleLine(true);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setTextColor(Color.parseColor("#333333"));
        textView.setTypeface(Typeface.DEFAULT);

        TableRow.LayoutParams params = new TableRow.LayoutParams(
                minWidth,
                TableRow.LayoutParams.WRAP_CONTENT
        );
        textView.setLayoutParams(params);

        return textView;
    }

    private TextView createHeaderTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextColor(Color.WHITE);
        textView.setPadding(dpToPx(6), dpToPx(12), dpToPx(6), dpToPx(12));
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setGravity(Gravity.CENTER);
        textView.setSingleLine(true);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setBackgroundColor(Color.parseColor("#1976D2"));
        return textView;
    }

    private Button createActionButton(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        button.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setAllCaps(false);

        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadius(dpToPx(4));
        shape.setColor(color);
        button.setBackground(shape);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                dpToPx(36),
                dpToPx(36)
        );
        params.setMargins(dpToPx(2), 0, dpToPx(2), 0);
        button.setLayoutParams(params);

        return button;
    }

    private int dpToPx(int dp) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp,
                getResources().getDisplayMetrics()
        );
    }

    // ALGORITMA SORTING BY NAMA
    private void sortByNama() {
        try {
            List<JSONObject> kreditorList = new ArrayList<>();
            for (int i = 0; i < arrayKreditor.length(); i++) {
                kreditorList.add(arrayKreditor.getJSONObject(i));
            }

            Collections.sort(kreditorList, new Comparator<JSONObject>() {
                @Override
                public int compare(JSONObject o1, JSONObject o2) {
                    try {
                        String nama1 = o1.getString("nama").toLowerCase();
                        String nama2 = o2.getString("nama").toLowerCase();
                        return sortNamaAscending ? nama1.compareTo(nama2) : nama2.compareTo(nama1);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        return 0;
                    }
                }
            });

            sortNamaAscending = !sortNamaAscending;
            btSortNama.setText(sortNamaAscending ? "SORT NAMA ↑" : "SORT NAMA ↓");

            JSONArray sortedArray = new JSONArray();
            for (JSONObject obj : kreditorList) {
                sortedArray.put(obj);
            }

            displayKreditorData(sortedArray);
            Toast.makeText(this, "Data diurutkan berdasarkan nama", Toast.LENGTH_SHORT).show();
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error sorting data", Toast.LENGTH_SHORT).show();
        }
    }

    // ALGORITMA SORTING BY PEKERJAAN
    private void sortByPekerjaan() {
        try {
            List<JSONObject> kreditorList = new ArrayList<>();
            for (int i = 0; i < arrayKreditor.length(); i++) {
                kreditorList.add(arrayKreditor.getJSONObject(i));
            }

            Collections.sort(kreditorList, new Comparator<JSONObject>() {
                @Override
                public int compare(JSONObject o1, JSONObject o2) {
                    try {
                        String pekerjaan1 = o1.getString("pekerjaan").toLowerCase();
                        String pekerjaan2 = o2.getString("pekerjaan").toLowerCase();
                        return sortPekerjaanAscending ? pekerjaan1.compareTo(pekerjaan2) : pekerjaan2.compareTo(pekerjaan1);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        return 0;
                    }
                }
            });

            sortPekerjaanAscending = !sortPekerjaanAscending;
            btSortPekerjaan.setText(sortPekerjaanAscending ? "SORT PEKERJAAN ↑" : "SORT PEKERJAAN ↓");

            JSONArray sortedArray = new JSONArray();
            for (JSONObject obj : kreditorList) {
                sortedArray.put(obj);
            }

            displayKreditorData(sortedArray);
            Toast.makeText(this, "Data diurutkan berdasarkan pekerjaan", Toast.LENGTH_SHORT).show();
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error sorting data", Toast.LENGTH_SHORT).show();
        }
    }

    // ALGORITMA SEARCHING
    private void searchKreditor() {
        String searchText = etSearch.getText().toString().trim().toLowerCase();

        if (TextUtils.isEmpty(searchText)) {
            displayKreditorData(originalArrayKreditor);
            Toast.makeText(this, "Menampilkan semua data", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            JSONArray filteredArray = new JSONArray();

            for (int i = 0; i < originalArrayKreditor.length(); i++) {
                JSONObject kreditor = originalArrayKreditor.getJSONObject(i);
                String nama = kreditor.optString("nama", "").toLowerCase();
                String pekerjaan = kreditor.optString("pekerjaan", "").toLowerCase();
                String telp = kreditor.optString("telp", "").toLowerCase();
                String alamat = kreditor.optString("alamat", "").toLowerCase();

                if (nama.contains(searchText) ||
                        pekerjaan.contains(searchText) ||
                        telp.contains(searchText) ||
                        alamat.contains(searchText)) {
                    filteredArray.put(kreditor);
                }
            }

            if (filteredArray.length() > 0) {
                arrayKreditor = filteredArray;
                displayKreditorData(filteredArray);
                Toast.makeText(this, "Ditemukan " + filteredArray.length() + " data", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Data tidak ditemukan", Toast.LENGTH_SHORT).show();
                displayKreditorData(new JSONArray());
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error searching data", Toast.LENGTH_SHORT).show();
        }
    }

    public void deleteKreditor(int idkreditor) {
        if (!session.getUserLevel().equals("admin")) {
            Toast.makeText(this, "Akses ditolak - Hanya admin yang bisa menghapus", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Konfirmasi Hapus")
                .setMessage("Apakah Anda yakin ingin menghapus kreditor ini?")
                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            String result = kreditor.deleteKreditor(String.valueOf(idkreditor));
                            // Parse response untuk menampilkan pesan yang benar
                            JSONObject jsonResponse = new JSONObject(result);
                            if (jsonResponse.getBoolean("success")) {
                                Toast.makeText(DataKreditorActivity.this, jsonResponse.getString("message"), Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(DataKreditorActivity.this, "Gagal: " + jsonResponse.getString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            Toast.makeText(DataKreditorActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                        // Refresh data
                        tampilDataKreditor();
                    }
                })
                .setNegativeButton("Tidak", null)
                .show();
    }

    public void getKreditorById(int idkreditor) {
        if (!session.getUserLevel().equals("admin")) {
            Toast.makeText(this, "Akses ditolak - Hanya admin yang bisa mengedit", Toast.LENGTH_SHORT).show();
            return;
        }

        String idkreditorEdit = null;
        String namaEdit = null;
        String pekerjaanEdit = null;
        String telpEdit = null;
        String alamatEdit = null;

        try {
            String response = kreditor.select_by_Idkreditor(String.valueOf(idkreditor));
            Log.d("DataKreditor", "Edit Response: " + response);

            // PERBAIKAN: Parse sebagai JSONObject
            JSONObject jsonResponse = new JSONObject(response);

            if (jsonResponse.getBoolean("success")) {
                JSONArray dataArray = jsonResponse.getJSONArray("data");
                if (dataArray.length() > 0) {
                    JSONObject jsonChildNode = dataArray.getJSONObject(0);
                    idkreditorEdit = jsonChildNode.optString("idkreditor");
                    namaEdit = jsonChildNode.optString("nama");
                    pekerjaanEdit = jsonChildNode.optString("pekerjaan");
                    telpEdit = jsonChildNode.optString("telp");
                    alamatEdit = jsonChildNode.optString("alamat");
                }
            } else {
                Toast.makeText(this, "Gagal mengambil data kreditor", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error mengambil data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return;
        }

        // Pastikan data tidak null
        if (idkreditorEdit == null) {
            Toast.makeText(this, "Data kreditor tidak ditemukan", Toast.LENGTH_SHORT).show();
            return;
        }

        LinearLayout layoutInput = new LinearLayout(this);
        layoutInput.setOrientation(LinearLayout.VERTICAL);
        layoutInput.setPadding(50, 20, 50, 20);

        final TextView viewIdKreditor = new TextView(this);
        viewIdKreditor.setText("ID Kreditor: " + String.valueOf(idkreditorEdit));
        viewIdKreditor.setTextColor(Color.BLACK);
        viewIdKreditor.setTextSize(16);
        viewIdKreditor.setPadding(0, 0, 0, 20);
        layoutInput.addView(viewIdKreditor);

        final EditText editIdKreditor = new EditText(this);
        editIdKreditor.setText(idkreditorEdit);
        editIdKreditor.setVisibility(View.GONE);
        layoutInput.addView(editIdKreditor);

        final EditText editNama = new EditText(this);
        editNama.setText(namaEdit != null ? namaEdit : "");
        editNama.setHint("Nama Kreditor");
        editNama.setPadding(0, 0, 0, 10);
        layoutInput.addView(editNama);

        final EditText editPekerjaan = new EditText(this);
        editPekerjaan.setText(pekerjaanEdit != null ? pekerjaanEdit : "");
        editPekerjaan.setHint("Pekerjaan");
        editPekerjaan.setPadding(0, 0, 0, 10);
        layoutInput.addView(editPekerjaan);

        final EditText editTelp = new EditText(this);
        editTelp.setText(telpEdit != null ? telpEdit : "");
        editTelp.setHint("Telepon");
        editTelp.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        editTelp.setPadding(0, 0, 0, 10);
        layoutInput.addView(editTelp);

        final EditText editAlamat = new EditText(this);
        editAlamat.setText(alamatEdit != null ? alamatEdit : "");
        editAlamat.setHint("Alamat");
        editAlamat.setPadding(0, 0, 0, 10);
        layoutInput.addView(editAlamat);

        AlertDialog.Builder builderEditKreditor = new AlertDialog.Builder(this);
        builderEditKreditor.setTitle("Update Kreditor");
        builderEditKreditor.setView(layoutInput);
        builderEditKreditor.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String idkreditor = editIdKreditor.getText().toString();
                String nama = editNama.getText().toString();
                String pekerjaan = editPekerjaan.getText().toString();
                String telp = editTelp.getText().toString();
                String alamat = editAlamat.getText().toString();

                // Validasi input
                if (TextUtils.isEmpty(nama) || TextUtils.isEmpty(pekerjaan) ||
                        TextUtils.isEmpty(telp) || TextUtils.isEmpty(alamat)) {
                    Toast.makeText(DataKreditorActivity.this, "Semua field harus diisi", Toast.LENGTH_SHORT).show();
                    return;
                }

                String result = kreditor.updateKreditor(idkreditor, nama, pekerjaan, telp, alamat);
                try {
                    JSONObject jsonResponse = new JSONObject(result);
                    if (jsonResponse.getBoolean("success")) {
                        Toast.makeText(DataKreditorActivity.this, jsonResponse.getString("message"), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(DataKreditorActivity.this, "Gagal: " + jsonResponse.getString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    Toast.makeText(DataKreditorActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }

                // Refresh data
                tampilDataKreditor();
            }
        });

        builderEditKreditor.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builderEditKreditor.show();
    }

    public void tambahKreditor() {
        if (!session.getUserLevel().equals("admin")) {
            Toast.makeText(this, "Akses ditolak - Hanya admin yang bisa menambah", Toast.LENGTH_SHORT).show();
            return;
        }

        LinearLayout layoutInput = new LinearLayout(this);
        layoutInput.setOrientation(LinearLayout.VERTICAL);
        layoutInput.setPadding(50, 20, 50, 20);

        final EditText editNama = new EditText(this);
        editNama.setHint("Nama Kreditor");
        editNama.setPadding(0, 0, 0, 10);
        layoutInput.addView(editNama);

        final EditText editPekerjaan = new EditText(this);
        editPekerjaan.setHint("Pekerjaan");
        editPekerjaan.setPadding(0, 0, 0, 10);
        layoutInput.addView(editPekerjaan);

        final EditText editTelp = new EditText(this);
        editTelp.setHint("Telepon");
        editTelp.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        editTelp.setPadding(0, 0, 0, 10);
        layoutInput.addView(editTelp);

        final EditText editAlamat = new EditText(this);
        editAlamat.setHint("Alamat");
        editAlamat.setPadding(0, 0, 0, 10);
        layoutInput.addView(editAlamat);

        AlertDialog.Builder builderInsertKreditor = new AlertDialog.Builder(this);
        builderInsertKreditor.setTitle("Tambah Kreditor");
        builderInsertKreditor.setView(layoutInput);
        builderInsertKreditor.setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String nama = editNama.getText().toString();
                String pekerjaan = editPekerjaan.getText().toString();
                String telp = editTelp.getText().toString();
                String alamat = editAlamat.getText().toString();

                // Validasi input
                if (TextUtils.isEmpty(nama) || TextUtils.isEmpty(pekerjaan) ||
                        TextUtils.isEmpty(telp) || TextUtils.isEmpty(alamat)) {
                    Toast.makeText(DataKreditorActivity.this, "Semua field harus diisi", Toast.LENGTH_SHORT).show();
                    return;
                }

                String result = kreditor.insertKreditor(nama, pekerjaan, telp, alamat);
                try {
                    JSONObject jsonResponse = new JSONObject(result);
                    if (jsonResponse.getBoolean("success")) {
                        Toast.makeText(DataKreditorActivity.this, jsonResponse.getString("message"), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(DataKreditorActivity.this, "Gagal: " + jsonResponse.getString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    Toast.makeText(DataKreditorActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }

                // Refresh data
                tampilDataKreditor();
            }
        });

        builderInsertKreditor.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builderInsertKreditor.show();
    }

    @Override
    public void onClick(View view) {
        if (!session.getUserLevel().equals("admin")) {
            return;
        }

        for (int i = 0; i < buttonEdit.size(); i++) {
            if (view.getId() == buttonEdit.get(i).getId() &&
                    view.getTag().toString().trim().equals("Edit")) {
                int idkreditor = buttonEdit.get(i).getId();
                getKreditorById(idkreditor);
            } else if (view.getId() == buttonDelete.get(i).getId() &&
                    view.getTag().toString().trim().equals("Delete")) {
                int idkreditor = buttonDelete.get(i).getId();
                deleteKreditor(idkreditor);
            }
        }
    }
}