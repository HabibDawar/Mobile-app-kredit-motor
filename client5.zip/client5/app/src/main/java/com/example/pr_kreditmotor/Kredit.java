package com.example.pr_kreditmotor;

public class Kredit extends Koneksi {
    private long id;
    Server server = new Server();

    String SERVER = server.urlDatabase1();
    String URL = "http://" + SERVER + "/jskreditmotor/tbkredit.php";
    String url = "";
    String response = "";

    // Method untuk menampilkan semua data kredit (admin)
    public String tampilKredit() {
        try {
            url = URL + "?operasi=view";
            System.out.println("URL tampilKredit: " + url);
            response = call(url);
        } catch (Exception e) {
            response = "Error: " + e.getMessage();
        }
        return response;
    }

    // Method untuk menampilkan kredit by kreditor (pelanggan)
    public String tampilKreditByKreditor(String idkreditor) {
        try {
            url = URL + "?operasi=view_by_kreditor&idkreditor=" + idkreditor;
            System.out.println("URL tampilKreditByKreditor: " + url);
            response = call(url);
        } catch (Exception e) {
            response = "Error: " + e.getMessage();
        }
        return response;
    }

    // Method untuk menampilkan data kredit dengan join (query lengkap)
    public String tampil_query_kredit() {
        try {
            url = URL + "?operasi=query_kredit";
            System.out.println("URL tampil_query_kredit: " + url);
            response = call(url);
        } catch (Exception e) {
            response = "Error: " + e.getMessage();
        }
        return response;
    }

    // Method untuk menampilkan kreditor by id dan nama
    public String tampilKreditorbyIdNama() {
        try {
            url = URL + "?operasi=select_by_idnama";
            System.out.println("URL Tampil_Kreditor: " + url);
            response = call(url);
        } catch (Exception e) {
            response = "Error: " + e.getMessage();
        }
        return response;
    }

    // Method untuk menyimpan kredit baru
    public String simpan_kredit(String idkreditor, String kdmotor, String hrgtunai, String dp,
                                String hrgkredit, String bunga, String lama,
                                String totalkredit, String angsuran) {
        try {
            url = URL + "?operasi=simpan_kredit&idkreditor=" + idkreditor +
                    "&kdmotor=" + kdmotor + "&hrgtunai=" + hrgtunai + "&dp=" + dp +
                    "&hrgkredit=" + hrgkredit + "&bunga=" + bunga + "&lama=" + lama +
                    "&totalkredit=" + totalkredit + "&angsuran=" + angsuran;
            System.out.println("URL simpan_kredit : " + url);
            response = call(url);
        } catch (Exception e) {
            response = "Error: " + e.getMessage();
        }
        return response;
    }

    // Method untuk menghapus kredit
    public String hapus_kredit(int invoice) {
        try {
            url = URL + "?operasi=hapus_kredit&invoice=" + invoice;
            System.out.println("URL Hapus kredit : " + url);
            response = call(url);
        } catch (Exception e) {
            response = "Error: " + e.getMessage();
        }
        return response;
    }

    // Method untuk approve kredit
    public String approveKredit(String invoice, String approvedBy) {
        try {
            url = URL + "?operasi=approve_kredit&invoice=" + invoice + "&approved_by=" + approvedBy;
            System.out.println("URL approveKredit: " + url);
            response = call(url);
        } catch (Exception e) {
            response = "Error: " + e.getMessage();
        }
        return response;
    }

    // Method untuk reject kredit
    public String rejectKredit(String invoice, String approvedBy) {
        try {
            url = URL + "?operasi=reject_kredit&invoice=" + invoice + "&approved_by=" + approvedBy;
            System.out.println("URL rejectKredit: " + url);
            response = call(url);
        } catch (Exception e) {
            response = "Error: " + e.getMessage();
        }
        return response;
    }

    // Method untuk mendapatkan kredit by invoice
    public String getKreditByInvoice(String invoice) {
        try {
            url = URL + "?operasi=get_by_invoice&invoice=" + invoice;
            System.out.println("URL getKreditByInvoice: " + url);
            response = call(url);
        } catch (Exception e) {
            response = "Error: " + e.getMessage();
        }
        return response;
    }

    // Method untuk update kredit
    public String updateKredit(String invoice, String idkreditor, String kdmotor, String hrgtunai,
                               String dp, String hrgkredit, String bunga, String lama,
                               String totalkredit, String angsuran) {
        try {
            url = URL + "?operasi=update_kredit&invoice=" + invoice + "&idkreditor=" + idkreditor +
                    "&kdmotor=" + kdmotor + "&hrgtunai=" + hrgtunai + "&dp=" + dp +
                    "&hrgkredit=" + hrgkredit + "&bunga=" + bunga + "&lama=" + lama +
                    "&totalkredit=" + totalkredit + "&angsuran=" + angsuran;
            System.out.println("URL update_kredit : " + url);
            response = call(url);
        } catch (Exception e) {
            response = "Error: " + e.getMessage();
        }
        return response;
    }

    // Method untuk mendapatkan laporan kredit
    public String getLaporanKredit(String bulan, String tahun) {
        try {
            url = URL + "?operasi=laporan_kredit&bulan=" + bulan + "&tahun=" + tahun;
            System.out.println("URL getLaporanKredit: " + url);
            response = call(url);
        } catch (Exception e) {
            response = "Error: " + e.getMessage();
        }
        return response;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}